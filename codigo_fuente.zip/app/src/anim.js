// Animación procedural: cada actividad escribe una pose objetivo en el rig.
// Ángulos en radianes; en pantalla (y hacia abajo) un ángulo positivo gira en sentido horario.
// El dragón mira a la derecha en coordenadas del rig.

const TAU = Math.PI * 2;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const lerp = (a, b, t) => a + (b - a) * t;
const smooth = (t) => t * t * (3 - 2 * t);

export const LEGS = ['HN', 'HF', 'FF', 'FN'];
const LEG_PARENT = { HN: 'hips', HF: 'hips', FF: 'chest', FN: 'chest' };
const TAIL = ['tail0', 'tail1', 'tail2', 'tail3', 'tail4', 'tail5', 'tail6', 'tail7', 'tail8', 'tail9'];
const NECK = ['neck0', 'neck1', 'neck2', 'neck3'];

export class Animator {
  constructor(rig) {
    this.rig = rig;
    const B = rig.bones, I = rig.idx;
    this.legInfo = {};
    for (const L of LEGS) {
      const up = B[I[L + '_up']], low = B[I[L + '_low']], foot = B[I[L + '_foot']];
      this.legInfo[L] = {
        up, low, foot, parent: B[I[LEG_PARENT[L]]],
        L1: up.len, L2: low.len,
        ankle: { x: low.end[0], y: low.end[1] },
        bend: 1,
      };
    }
    this.groundY = rig.data.groundY;
    this.headRest = B[I.head].restAngle;
    this._m = { root: new Float32Array(6), hips: new Float32Array(6), chest: new Float32Array(6) };
  }

  // --- utilidades de pose objetivo ---
  set(n, p, v) { this.rig.target[p][this.rig.idx[n]] = v; }
  add(n, p, v) { this.rig.target[p][this.rig.idx[n]] += v; }
  get(n, p) { return this.rig.target[p][this.rig.idx[n]]; }

  localMatrix(b) {
    const T = this.rig.target, i = b.i;
    const r = T.rot[i], cs = Math.cos(r), sn = Math.sin(r);
    const a = cs * T.sx[i], bb = sn * T.sx[i], c = -sn * T.sy[i], d = cs * T.sy[i];
    return [a, bb, c, d, b.px + T.tx[i] - (a * b.px + c * b.py), b.py + T.ty[i] - (bb * b.px + d * b.py)];
  }
  static mul(P, L) {
    return [P[0] * L[0] + P[2] * L[1], P[1] * L[0] + P[3] * L[1], P[0] * L[2] + P[2] * L[3],
      P[1] * L[2] + P[3] * L[3], P[0] * L[4] + P[2] * L[5] + P[4], P[1] * L[4] + P[3] * L[5] + P[5]];
  }

  // IK de dos huesos: coloca el tobillo de la pata en (tx,ty) (coords del rig) y el pie con ángulo footAng (mundo)
  legIK(L, tx, ty, footAng = null) {
    const info = this.legInfo[L], B = this.rig.bones, T = this.rig.target;
    const root = B[0];
    const Mroot = this.localMatrix(root);
    const Mpar = Animator.mul(Mroot, this.localMatrix(info.parent));
    const hp = info.up;
    const hx = Mpar[0] * hp.px + Mpar[2] * hp.py + Mpar[4];
    const hy = Mpar[1] * hp.px + Mpar[3] * hp.py + Mpar[5];
    const cum = T.rot[0] + T.rot[info.parent.i];
    let dx = tx - hx, dy = ty - hy;
    let d = Math.hypot(dx, dy);
    const { L1, L2 } = info;
    d = clamp(d, Math.abs(L1 - L2) + 2, L1 + L2 - 0.5);
    const a = Math.atan2(dy, dx);
    const cb = clamp((L1 * L1 + d * d - L2 * L2) / (2 * L1 * d), -1, 1);
    const th1 = a + info.bend * Math.acos(cb);
    const kx = hx + L1 * Math.cos(th1), ky = hy + L1 * Math.sin(th1);
    const th2 = Math.atan2(ty - ky, tx - kx);
    const r1 = th1 - info.up.restAngle - cum;
    const r2 = th2 - info.low.restAngle - cum - r1;
    T.rot[info.up.i] = r1;
    T.rot[info.low.i] = r2;
    const fa = footAng === null ? info.foot.restAngle : footAng;
    T.rot[info.foot.i] = fa - info.foot.restAngle - cum - r1 - r2;
  }

  // Cadena con ángulos de mundo deseados (relativos al marco del padre de la cadena)
  chainWorld(names, angles, w = 1) {
    let cum = 0;
    for (let k = 0; k < names.length; k++) {
      const b = this.rig.bones[this.rig.idx[names[k]]];
      const want = angles[k] - b.restAngle - cum;
      const cur = this.rig.target.rot[b.i];
      const r = lerp(cur, want, w);
      this.rig.target.rot[b.i] = r;
      cum += r;
    }
  }

  look(D, w = 1) {
    // D.look = {x,y} en coords del rig, o null
    if (!D.look) return;
    const hp = this.rig.bones[this.rig.idx.head];
    const ang = Math.atan2(D.look.y - hp.py, D.look.x - hp.px);
    let delta = ang - this.headRest;
    while (delta > Math.PI) delta -= TAU;
    while (delta < -Math.PI) delta += TAU;
    delta = clamp(delta, -0.9, 0.7) * w;
    this.add('neck1', 'rot', delta * 0.12);
    this.add('neck2', 'rot', delta * 0.18);
    this.add('neck3', 'rot', delta * 0.25);
    this.add('head', 'rot', delta * 0.45);
  }

  breathe(D, amp = 1) {
    const s = Math.sin(D.t * TAU * D.breathRate);
    this.add('chest', 'sy', 0.012 * s * amp);
    this.add('chest', 'sx', 0.006 * s * amp);
    this.add('neck0', 'rot', -0.012 * s * amp);
    this.add('head', 'rot', 0.01 * s * amp);
    this.add('wing', 'rot', -0.012 * s * amp);
    this.add('wingFar', 'rot', -0.01 * s * amp);
  }

  tailSway(D, amp = 1, speed = 1) {
    for (let k = 0; k < TAIL.length; k++) {
      this.add(TAIL[k], 'rot', amp * 0.045 * Math.sin(D.t * 1.3 * speed - k * 0.55) * (0.4 + k * 0.12));
    }
  }

  standLegs(D, crouch = 0) {
    for (const L of LEGS) {
      const a = this.legInfo[L].ankle;
      this.legIK(L, a.x, a.y);
    }
  }

  wingsRest(D, fold = 0) {
    // fold 0 = alas alzadas (pose de la ficha); 1 = plegadas sobre el lomo
    this.add('wing', 'rot', lerp(0, -0.46, fold));
    this.add('wing', 'sy', lerp(0, -0.37, fold));
    this.add('wingTip', 'rot', lerp(0, 0.26, fold));
    this.add('wingFar', 'rot', lerp(-0.1, -0.55, fold));
    this.add('wingFar', 'sy', lerp(-0.12, -0.43, fold));
    this.add('wingFarTip', 'rot', lerp(0.05, 0.26, fold));
  }

  flap(phase, amp = 1, far = true) {
    // fase 0..1; bajada rápida (45%), subida lenta
    const u = phase < 0.45 ? (phase / 0.45) * 0.5 : 0.5 + ((phase - 0.45) / 0.55) * 0.5;
    const c = Math.cos(TAU * u), s = Math.sin(TAU * u);
    this.set('wing', 'sy', lerp(0.75, c * 0.98, amp));
    this.add('wing', 'rot', -0.22 * s * amp - 0.05);
    this.add('wingTip', 'rot', 0.38 * Math.sin(TAU * u - 1.3) * amp);
    const u2 = (u - 0.04 + 1) % 1;
    const c2 = Math.cos(TAU * u2), s2 = Math.sin(TAU * u2);
    this.set('wingFar', 'sy', lerp(0.7, c2 * 0.9, amp));
    this.add('wingFar', 'rot', -0.2 * s2 * amp - 0.1);
    this.add('wingFarTip', 'rot', 0.34 * Math.sin(TAU * u2 - 1.3) * amp);
    return { lift: s, u };
  }

  // ---------------- Actividades ----------------
  apply(D, dt) {
    const T = this.rig.target;
    T.reset();
    const act = D.act;
    const f = this[act] || this.stand;
    f.call(this, D, dt);
    // cola y alas siempre un poco vivas
    if (D.blinkTint !== undefined) { /* reservado */ }
  }

  stand(D) {
    this.breathe(D);
    this.tailSway(D, D.mood === 'enfadado' ? 2.2 : 1, D.mood === 'enfadado' ? 2.5 : 1);
    this.wingsRest(D, D.wingFold ?? 0.25);
    this.add('root', 'ty', 0);
    this.look(D, 1);
    this.standLegs(D);
    if (D.mood === 'enfadado') { this.add('neck0', 'rot', 0.08); this.add('head', 'rot', 0.12); }
    if (D.mood === 'curioso') { this.add('head', 'rot', -0.1 + 0.06 * Math.sin(D.t * 0.9)); }
  }

  walk(D) { this.gait(D, false); }
  run(D) { this.gait(D, true); }

  gait(D, run) {
    const ph = D.gaitPhase; // 0..1, avanzado por el controlador según velocidad
    const stance = run ? 0.42 : 0.62;
    const stride = run ? 120 : 64;
    const lift = run ? 26 : 16;
    const offs = run ? { HN: 0, HF: 0.1, FN: 0.5, FF: 0.6 } : { HN: 0, FN: 0.25, HF: 0.5, FF: 0.75 };
    // cuerpo
    const bob = run ? Math.sin(ph * TAU) : Math.sin(ph * TAU * 2);
    this.add('root', 'ty', run ? -10 * Math.max(0, bob) + 4 : -2.5 * bob);
    this.add('root', 'rot', run ? 0.06 * Math.sin(ph * TAU + 1.2) : 0.012 * Math.sin(ph * TAU));
    if (run) {
      this.add('hips', 'rot', 0.08 * Math.sin(ph * TAU));
      this.add('chest', 'rot', -0.06 * Math.sin(ph * TAU));
      this.add('neck0', 'rot', 0.18);
      this.add('neck1', 'rot', 0.12);
      this.add('neck2', 'rot', 0.05);
      this.add('head', 'rot', -0.1 + 0.05 * Math.sin(ph * TAU * 2));
    } else {
      this.add('neck1', 'rot', 0.03 * Math.sin(ph * TAU * 2 + 0.6));
      this.add('head', 'rot', -0.03 * Math.sin(ph * TAU * 2 + 0.6));
    }
    this.breathe(D, 0.6);
    this.look(D, 0.5);
    // cola: más horizontal al correr
    if (run) {
      const ang = []; for (let k = 0; k < 10; k++) ang.push(Math.PI - 0.15 + 0.12 * Math.sin(D.t * 6 - k * 0.7) * (k / 9) + (k > 5 ? -0.05 * (k - 5) : 0));
      this.chainWorld(TAIL, ang, 0.85);
    } else this.tailSway(D, 1.6, 2.4);
    this.wingsRest(D, run ? 0.35 : (D.wingFold ?? 0.25));
    if (run) { this.add('wing', 'rot', 0.08 * Math.sin(ph * TAU)); this.add('wingFar', 'rot', 0.06 * Math.sin(ph * TAU + 0.5)); }
    // patas con pies plantados
    for (const L of LEGS) {
      const a = this.legInfo[L].ankle;
      let p = (ph + offs[L]) % 1;
      let x, y, fa = null;
      if (p < stance) { // apoyo: el pie retrocede
        const s = p / stance; x = a.x + stride * (0.5 - s); y = a.y;
      } else {           // vuelo de la pata: se levanta y avanza
        const s = (p - stance) / (1 - stance); const e = smooth(s);
        x = a.x + stride * (-0.5 + e); y = a.y - lift * Math.sin(Math.PI * s);
        fa = this.legInfo[L].foot.restAngle + (L[0] === 'H' ? 0.5 : -0.3) * Math.sin(Math.PI * s);
      }
      this.legIK(L, x, y, fa);
    }
  }

  crouch(D) {
    const c = D.crouch ?? 1;
    this.breathe(D, 0.5);
    this.add('root', 'ty', 34 * c);
    this.add('root', 'rot', 0.05 * c);
    this.add('neck0', 'rot', 0.15 * c);
    this.add('neck1', 'rot', 0.1 * c);
    this.add('head', 'rot', -0.15 * c);
    this.wingsRest(D, 0);
    this.add('wing', 'sy', 0.0); this.add('wing', 'rot', 0.12 * c);
    this.tailSway(D, 0.6);
    this.look(D, 0.8);
    for (const L of LEGS) {
      const a = this.legInfo[L].ankle;
      this.legIK(L, a.x + (L[0] === 'H' ? 8 : -6) * c, a.y);
    }
  }

  sit(D) {
    this.breathe(D);
    this.add('root', 'rot', -0.36);
    this.add('root', 'ty', 30);
    this.add('root', 'tx', -6);
    this.add('neck0', 'rot', 0.12); this.add('neck1', 'rot', 0.1); this.add('neck2', 'rot', 0.06); this.add('head', 'rot', 0.08);
    this.add('tail0', 'rot', 0.3); this.add('tail1', 'rot', 0.12);
    this.tailSway(D, 1.2, 1.2);
    this.wingsRest(D, D.wingFold ?? 0.55);
    this.look(D, 1);
    const g = this.groundY - 6;
    this.legIK('HN', 330, g + 2, this.legInfo.HN.foot.restAngle);
    this.legIK('HF', 395, g, this.legInfo.HF.foot.restAngle);
    this.legIK('FF', 488, g + 2);
    this.legIK('FN', 535, g + 4);
  }

  lie(D) {
    this.breathe(D, 1.2);
    this.add('root', 'ty', 62);
    this.add('root', 'rot', 0.02);
    this.add('neck0', 'rot', 0.22); this.add('neck1', 'rot', 0.12);
    this.add('head', 'rot', -0.05);
    this.chainWorld(TAIL, [Math.PI - 0.3, Math.PI - 0.12, Math.PI - 0.04, Math.PI, Math.PI, Math.PI + 0.06, Math.PI + 0.16, Math.PI + 0.32, Math.PI + 0.55, Math.PI + 0.8], 0.85);
    this.tailSway(D, 0.6, 0.6);
    this.wingsRest(D, 0.85);
    this.look(D, 0.7);
    const g = this.groundY - 4;
    this.legIK('HN', 360, g, this.legInfo.HN.foot.restAngle - 0.2);
    this.legIK('HF', 420, g - 2, this.legInfo.HF.foot.restAngle - 0.2);
    this.legIK('FF', 545, g, -0.05);
    this.legIK('FN', 590, g + 2, -0.05);
  }

  sleep(D) {
    this.lie(D);
    const s = Math.sin(D.t * TAU * 0.22);
    this.add('chest', 'sy', 0.03 * s);
    this.add('neck0', 'rot', 0.25); this.add('neck1', 'rot', 0.35); this.add('neck2', 'rot', 0.25);
    this.add('neck3', 'rot', 0.05); this.add('head', 'rot', -0.25 + 0.015 * s);
    for (let k = 0; k < 10; k++) this.add(TAIL[k], 'rot', 0.03 * k * 0.3);
    this.add('wing', 'rot', -0.1); this.add('wing', 'sy', -0.14); this.add('wingFar', 'rot', -0.08); this.add('wingFar', 'sy', -0.1);
  }

  stretch(D) {
    // reverencia: patas delanteras estiradas, grupa alta, alas abiertas
    const p = D.actT ?? 0; const k = smooth(clamp(p / 0.8, 0, 1)) * (1 - smooth(clamp((p - 2.2) / 0.8, 0, 1)));
    this.add('root', 'rot', 0.28 * k);
    this.add('root', 'ty', 22 * k);
    this.add('neck0', 'rot', -0.2 * k); this.add('neck1', 'rot', -0.1 * k); this.add('head', 'rot', -0.15 * k);
    this.wingsRest(D, 0);
    this.add('wing', 'rot', -0.1 * k); this.add('wingTip', 'rot', -0.15 * k);
    this.add('wingFar', 'rot', 0.12 * k); this.add('wingFar', 'sy', 0.1 * k);
    const ang = []; for (let j = 0; j < 10; j++) ang.push(Math.PI + 0.35 - j * 0.04);
    this.chainWorld(TAIL, ang, 0.6 * k);
    this.tailSway(D, 1);
    for (const L of LEGS) {
      const a = this.legInfo[L].ankle;
      this.legIK(L, a.x + (L[0] === 'F' ? 45 * k : -5 * k), a.y);
    }
  }

  shake(D) {
    // sacudir alas
    this.stand(D);
    const s = Math.sin(D.t * 38);
    this.set('wing', 'sy', 0.85 + 0.15 * s);
    this.add('wing', 'rot', 0.12 * s);
    this.add('wingTip', 'rot', 0.25 * Math.sin(D.t * 38 - 1));
    this.set('wingFar', 'sy', 0.8 + 0.14 * Math.sin(D.t * 38 - 0.6));
    this.add('neck2', 'rot', 0.08 * Math.sin(D.t * 22));
    this.add('head', 'rot', 0.12 * Math.sin(D.t * 22 + 1));
    this.add('root', 'ty', 1.5 * Math.sin(D.t * 38));
  }

  fly(D) {
    const r = this.flap(D.flapPhase, D.flapAmp ?? 1);
    this.add('root', 'ty', -7 * r.lift);
    this.add('root', 'rot', D.pitch ?? 0);
    // cuello hacia delante
    this.chainWorld([...NECK, 'head'], [-0.95, -0.7, -0.45, -0.25, 0.12], 0.9);
    this.add('head', 'rot', 0.04 * Math.sin(D.flapPhase * TAU));
    this.look(D, 0.4);
    // cola estirada ondulando
    const ang = []; for (let k = 0; k < 10; k++) ang.push(Math.PI - 0.1 + 0.16 * Math.sin(D.t * 4 - k * 0.6) * (0.3 + k / 12));
    this.chainWorld(TAIL, ang, 0.9);
    this.tuckLegs(D, 1);
  }

  hover(D) {
    const r = this.flap(D.flapPhase, 1);
    this.add('root', 'ty', -9 * r.lift);
    this.add('root', 'rot', -0.32 + (D.pitch ?? 0));
    this.add('neck0', 'rot', 0.25); this.add('neck1', 'rot', 0.15); this.add('head', 'rot', 0.1);
    this.look(D, 0.9);
    const ang = []; for (let k = 0; k < 10; k++) ang.push(Math.PI * 0.62 + 0.18 * Math.sin(D.t * 3 - k * 0.6) * (k / 9) + k * 0.06);
    this.chainWorld(TAIL, ang, 0.7);
    this.tuckLegs(D, 0.45);
    if (D.reach) { // patas delanteras hacia delante (atrapar / empujar)
      this.set('FN_up', 'rot', -0.9); this.set('FN_low', 'rot', -0.5);
      this.set('FF_up', 'rot', -0.7); this.set('FF_low', 'rot', -0.4);
    }
  }

  glide(D) {
    this.set('wing', 'sy', 0.32 + 0.04 * Math.sin(D.t * 2));
    this.add('wing', 'rot', -0.05);
    this.add('wingTip', 'rot', -0.12);
    this.set('wingFar', 'sy', 0.24); this.add('wingFar', 'rot', -0.1);
    this.add('root', 'rot', (D.pitch ?? 0) + 0.04);
    this.add('root', 'ty', 2 * Math.sin(D.t * 1.5));
    this.chainWorld([...NECK, 'head'], [-0.95, -0.7, -0.45, -0.25, 0.14], 0.9);
    this.look(D, 0.4);
    const ang = []; for (let k = 0; k < 10; k++) ang.push(Math.PI - 0.08 + 0.08 * Math.sin(D.t * 2 - k * 0.5) * (k / 9));
    this.chainWorld(TAIL, ang, 0.9);
    this.tuckLegs(D, 1);
  }

  tuckLegs(D, k) {
    this.set('HN_up', 'rot', 1.25 * k); this.set('HN_low', 'rot', 0.25 * k); this.set('HN_foot', 'rot', 0.6 * k);
    this.set('HF_up', 'rot', 1.15 * k); this.set('HF_low', 'rot', 0.2 * k); this.set('HF_foot', 'rot', 0.6 * k);
    this.set('FN_up', 'rot', 0.85 * k); this.set('FN_low', 'rot', -1.55 * k); this.set('FN_foot', 'rot', 0.5 * k);
    this.set('FF_up', 'rot', 0.8 * k); this.set('FF_low', 'rot', -1.5 * k); this.set('FF_foot', 'rot', 0.5 * k);
  }

  fire(D) {
    // carga (0-0.6s), llamarada, recuperación
    const p = D.actT ?? 0;
    const charge = smooth(clamp(p / 0.6, 0, 1));
    const blast = p > 0.6 ? 1 : 0;
    this.breathe(D, 0.4);
    this.wingsRest(D, 0);
    this.add('wing', 'rot', 0.08 * charge);
    this.add('root', 'ty', 6 * charge);
    this.add('neck0', 'rot', lerp(0, -0.25, charge) + blast * 0.35);
    this.add('neck1', 'rot', lerp(0, -0.2, charge) + blast * 0.3);
    this.add('neck2', 'rot', lerp(0, -0.15, charge) + blast * 0.18);
    this.add('neck3', 'rot', blast * 0.05);
    this.add('head', 'rot', lerp(0, -0.25, charge) + blast * (0.3 + 0.03 * Math.sin(D.t * 30)));
    this.add('chest', 'sy', 0.04 * charge * (1 - blast));
    this.tailSway(D, 2, 3);
    for (const L of LEGS) { const a = this.legInfo[L].ankle; this.legIK(L, a.x + (L[0] === 'H' ? -10 : 8) * charge, a.y); }
  }

  roar(D) {
    const p = D.actT ?? 0; const k = Math.sin(clamp(p / 1.4, 0, 1) * Math.PI);
    this.stand(D);
    this.add('neck0', 'rot', -0.2 * k); this.add('neck1', 'rot', -0.25 * k); this.add('neck2', 'rot', -0.2 * k);
    this.add('head', 'rot', -0.45 * k + 0.02 * Math.sin(D.t * 40) * k);
    this.set('wing', 'sy', 1); this.add('wing', 'rot', 0.08 * k);
    this.add('root', 'rot', -0.06 * k);
  }

  kick(D) {
    const p = D.actT ?? 0;
    const wind = smooth(clamp(p / 0.35, 0, 1));
    const strike = smooth(clamp((p - 0.35) / 0.12, 0, 1));
    const back = smooth(clamp((p - 0.7) / 0.4, 0, 1));
    this.stand(D);
    this.add('root', 'rot', -0.05 * wind + 0.05 * back);
    const a = this.legInfo.FN.ankle;
    const x = a.x + lerp(lerp(0, -25, wind), 55, strike) * (1 - back);
    const y = a.y - lerp(lerp(0, 22, wind), 40, strike) * (1 - back);
    this.legIK('FN', x, y, this.legInfo.FN.foot.restAngle - 0.6 * strike * (1 - back));
    this.add('head', 'rot', 0.2 * wind * (1 - back));
  }

  push(D) {
    // empujar: inclinado hacia delante, patas delanteras alzadas apoyadas
    const s = Math.sin(D.t * 8);
    this.breathe(D, 0.5);
    this.wingsRest(D, 0.1);
    this.add('wing', 'rot', 0.05 * s);
    this.add('root', 'rot', -0.42);
    this.add('root', 'tx', -10);
    this.add('root', 'ty', 24);
    this.add('neck0', 'rot', 0.3); this.add('neck1', 'rot', 0.25); this.add('neck2', 'rot', 0.1); this.add('head', 'rot', 0.25);
    this.tailSway(D, 1.5, 2);
    this.add('tail0', 'rot', 0.35);
    const g = this.groundY;
    this.legIK('HN', 330 + 6 * s, g, this.legInfo.HN.foot.restAngle);
    this.legIK('HF', 400 - 6 * s, g);
    this.legIK('FF', 600, 300 + 4 * s, -1.2);
    this.legIK('FN', 610, 320 - 4 * s, -1.2);
  }

  grab(D) {
    // agacharse a coger algo con la boca
    const p = D.actT ?? 0; const k = Math.sin(clamp(p / 1.2, 0, 1) * Math.PI);
    this.breathe(D, 0.5);
    this.wingsRest(D, 0.3);
    this.add('root', 'rot', 0.12 * k);
    this.add('root', 'ty', 10 * k);
    this.add('neck0', 'rot', 0.5 * k); this.add('neck1', 'rot', 0.6 * k); this.add('neck2', 'rot', 0.4 * k); this.add('neck3', 'rot', 0.2 * k);
    this.add('head', 'rot', 0.35 * k);
    this.tailSway(D, 1.2, 1.5);
    this.standLegs(D);
  }

  pounce(D) {
    // en el aire durante un salto
    this.wingsRest(D, 0);
    this.set('wing', 'sy', 0.95);
    this.add('root', 'rot', D.pitch ?? -0.15);
    this.add('neck0', 'rot', 0.15); this.add('neck1', 'rot', 0.1); this.add('head', 'rot', 0.1);
    this.look(D, 0.8);
    this.set('FN_up', 'rot', -1.0); this.set('FN_low', 'rot', -0.3); this.set('FN_foot', 'rot', -0.3);
    this.set('FF_up', 'rot', -0.8); this.set('FF_low', 'rot', -0.25);
    this.set('HN_up', 'rot', 0.6); this.set('HN_low', 'rot', 0.2);
    this.set('HF_up', 'rot', 0.5); this.set('HF_low', 'rot', 0.2);
    const ang = []; for (let k = 0; k < 10; k++) ang.push(Math.PI - 0.25 + 0.05 * k);
    this.chainWorld(TAIL, ang, 0.7);
  }

  dangle(D) {
    // agarrado por el usuario: patas colgando y pataleando
    const s = Math.sin(D.t * 9);
    this.wingsRest(D, 0);
    this.set('wing', 'sy', 0.6 + 0.35 * Math.sin(D.t * 14));
    this.set('wingFar', 'sy', 0.55 + 0.3 * Math.sin(D.t * 14 - 0.5));
    this.add('neck0', 'rot', -0.1); this.add('neck1', 'rot', -0.1); this.add('head', 'rot', 0.1 * Math.sin(D.t * 3));
    this.look(D, 0.6);
    this.set('HN_up', 'rot', 0.25 * s); this.set('HN_low', 'rot', 0.2 * Math.sin(D.t * 9 + 1));
    this.set('HF_up', 'rot', -0.25 * s); this.set('HF_low', 'rot', 0.2 * Math.sin(D.t * 9 + 2));
    this.set('FN_up', 'rot', -0.3 * Math.sin(D.t * 9 + 1.5)); this.set('FN_low', 'rot', -0.3);
    this.set('FF_up', 'rot', 0.3 * Math.sin(D.t * 9 + 1.5)); this.set('FF_low', 'rot', -0.3);
    const ang = []; for (let k = 0; k < 10; k++) ang.push(Math.PI * 0.55 + 0.25 * Math.sin(D.t * 4 - k * 0.5) * (k / 9));
    this.chainWorld(TAIL, ang, 0.8);
  }

  yawn(D) {
    const p = D.actT ?? 0; const k = Math.sin(clamp(p / 2, 0, 1) * Math.PI);
    this.sit(D);
    this.add('neck1', 'rot', -0.2 * k); this.add('neck2', 'rot', -0.2 * k); this.add('head', 'rot', -0.35 * k);
    this.add('chest', 'sy', 0.04 * k);
  }

  happy(D) {
    // saltito de alegría con cola movida
    const p = D.actT ?? 0;
    const hop = Math.max(0, Math.sin(p * TAU * 1.6)) * (p < 1.3 ? 1 : 0);
    this.stand(D);
    this.add('root', 'ty', -16 * hop);
    this.set('wing', 'sy', 0.8 + 0.2 * Math.sin(p * 20));
    this.tailSway(D, 3, 4);
    for (const L of LEGS) { const a = this.legInfo[L].ankle; this.legIK(L, a.x, a.y - 14 * hop); }
  }
}
