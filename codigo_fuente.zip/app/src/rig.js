// Motor de esqueleto 2D: cinemática directa + skinning lineal sobre mallas PixiJS.
import { Container, Mesh, MeshGeometry } from 'pixi.js';

const PARAMS = ['rot', 'sx', 'sy', 'tx', 'ty'];
const DEFAULT = { rot: 0, sx: 1, sy: 1, tx: 0, ty: 0 };

export class Pose {
  constructor(n) {
    this.n = n;
    for (const p of PARAMS) this[p] = new Float32Array(n).fill(DEFAULT[p]);
  }
  reset() { for (const p of PARAMS) this[p].fill(DEFAULT[p]); }
  copyFrom(o) { for (const p of PARAMS) this[p].set(o[p]); }
}

function mul(P, L, out) {
  const a = P[0] * L[0] + P[2] * L[1], b = P[1] * L[0] + P[3] * L[1];
  const c = P[0] * L[2] + P[2] * L[3], d = P[1] * L[2] + P[3] * L[3];
  const tx = P[0] * L[4] + P[2] * L[5] + P[4], ty = P[1] * L[4] + P[3] * L[5] + P[5];
  out[0] = a; out[1] = b; out[2] = c; out[3] = d; out[4] = tx; out[5] = ty;
  return out;
}

export class Rig {
  constructor(data, textures) {
    this.data = data;
    this.size = data.size;
    this.bones = data.bones.map((b, i) => ({ ...b, i, m: new Float32Array([1, 0, 0, 1, 0, 0]) }));
    this.idx = {};
    this.bones.forEach((b, i) => {
      this.idx[b.name] = i;
      b.restAngle = b.end ? Math.atan2(b.end[1] - b.py, b.end[0] - b.px) : 0;
      b.len = b.end ? Math.hypot(b.end[0] - b.px, b.end[1] - b.py) : 0;
    });
    const n = this.bones.length;
    this.pose = new Pose(n);      // pose real (suavizada)
    this.target = new Pose(n);    // pose objetivo del frame
    this.view = new Container();
    this.layers = {};
    const order = [['wingFar', 'wing'], ['body', 'body'], ['wing', 'wing']];
    for (const [key, tex] of order) {
      const md = data.meshes[key];
      const rest = new Float32Array(md.pos);
      const uvs = new Float32Array(rest.length);
      for (let i = 0; i < rest.length; i += 2) { uvs[i] = rest[i] / this.size[0]; uvs[i + 1] = rest[i + 1] / this.size[1]; }
      const geometry = new MeshGeometry({ positions: new Float32Array(rest), uvs, indices: new Uint32Array(md.idx) });
      const mesh = new Mesh({ geometry, texture: textures[tex] });
      this.view.addChild(mesh);
      this.layers[key] = {
        mesh, rest, out: geometry.getBuffer('aPosition'),
        bi: new Uint16Array(md.bi), bw: new Float32Array(md.bw),
      };
    }
    this.layers.wingFar.mesh.tint = 0x8f6b58;
    this._L = new Float32Array(6);
  }

  b(name) { return this.idx[name]; }

  // Suaviza la pose real hacia la objetivo (transiciones naturales).
  blend(dt, k) {
    const a = 1 - Math.exp(-k * dt);
    for (const p of PARAMS) {
      const P = this.pose[p], T = this.target[p];
      for (let i = 0; i < P.length; i++) P[i] += (T[i] - P[i]) * a;
    }
  }

  snap() { this.pose.copyFrom(this.target); }

  computeMatrices() {
    const P = this.pose, L = this._L;
    for (const b of this.bones) {
      const i = b.i, r = P.rot[i], sx = P.sx[i], sy = P.sy[i];
      const cs = Math.cos(r), sn = Math.sin(r);
      L[0] = cs * sx; L[1] = sn * sx; L[2] = -sn * sy; L[3] = cs * sy;
      L[4] = b.px + P.tx[i] - (L[0] * b.px + L[2] * b.py);
      L[5] = b.py + P.ty[i] - (L[1] * b.px + L[3] * b.py);
      if (b.parent < 0) b.m.set(L);
      else mul(this.bones[b.parent].m, L, b.m);
    }
  }

  skin() {
    const bones = this.bones;
    for (const key in this.layers) {
      const Ly = this.layers[key];
      if (!Ly.mesh.visible) continue;
      const rest = Ly.rest, out = Ly.out.data, bi = Ly.bi, bw = Ly.bw;
      for (let v = 0, n = rest.length / 2; v < n; v++) {
        const x = rest[2 * v], y = rest[2 * v + 1];
        let ox = 0, oy = 0;
        for (let k = 0; k < 4; k++) {
          const w = bw[4 * v + k];
          if (w <= 0) continue;
          const m = bones[bi[4 * v + k]].m;
          ox += w * (m[0] * x + m[2] * y + m[4]);
          oy += w * (m[1] * x + m[3] * y + m[5]);
        }
        out[2 * v] = ox; out[2 * v + 1] = oy;
      }
      Ly.out.update();
    }
  }

  update(dt, k) {
    this.blend(dt, k);
    this.computeMatrices();
    this.skin();
  }

  // Punto del rig (coordenadas de reposo) transformado por un hueso -> coords locales del view
  point(boneName, x, y) {
    const m = this.bones[this.idx[boneName]].m;
    return { x: m[0] * x + m[2] * y + m[4], y: m[1] * x + m[3] * y + m[5] };
  }
  boneAngle(boneName) {
    const m = this.bones[this.idx[boneName]].m;
    return Math.atan2(m[1], m[0]);
  }
  matrix(boneName) { return this.bones[this.idx[boneName]].m; }
}
