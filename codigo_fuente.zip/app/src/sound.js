// Sonidos sintetizados con WebAudio (sin archivos): aleteo, fuego, rugido, gorjeo, ronquido, golpe.
export class Sound {
  constructor() { this.ctx = null; this.vol = 0.5; this.master = null; this._noise = null; }
  ensure() {
    if (this.ctx) { if (this.ctx.state === 'suspended') this.ctx.resume(); return true; }
    try {
      this.ctx = new (window.AudioContext || window.webkitAudioContext)();
      this.master = this.ctx.createGain(); this.master.gain.value = this.vol * 0.6;
      this.master.connect(this.ctx.destination);
      const len = this.ctx.sampleRate * 2, buf = this.ctx.createBuffer(1, len, this.ctx.sampleRate), d = buf.getChannelData(0);
      for (let i = 0; i < len; i++) d[i] = Math.random() * 2 - 1;
      this._noise = buf;
      return true;
    } catch { return false; }
  }
  setVolume(v) { this.vol = v; if (this.master) this.master.gain.value = v * 0.6; }
  suspend() { if (this.ctx && this.ctx.state === 'running') this.ctx.suspend(); }
  ok() { return this.vol > 0.001 && this.ensure() && this.ctx.state !== 'closed'; }

  noise(dur, { type = 'bandpass', f0 = 800, f1 = 400, q = 1, gain = 0.5, attack = 0.01, pan = 0 } = {}) {
    const c = this.ctx, t = c.currentTime;
    const src = c.createBufferSource(); src.buffer = this._noise; src.loop = true;
    const fl = c.createBiquadFilter(); fl.type = type; fl.Q.value = q;
    fl.frequency.setValueAtTime(f0, t); fl.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + attack); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    const p = c.createStereoPanner ? c.createStereoPanner() : null;
    src.connect(fl); fl.connect(g);
    if (p) { p.pan.value = pan; g.connect(p); p.connect(this.master); } else g.connect(this.master);
    src.start(t, Math.random()); src.stop(t + dur + 0.05);
  }
  tone(dur, { type = 'sine', f0 = 440, f1 = 440, gain = 0.3, attack = 0.02, pan = 0, filter = 0 } = {}) {
    const c = this.ctx, t = c.currentTime;
    const o = c.createOscillator(); o.type = type;
    o.frequency.setValueAtTime(f0, t); o.frequency.exponentialRampToValueAtTime(Math.max(20, f1), t + dur);
    const g = c.createGain(); g.gain.setValueAtTime(0.0001, t);
    g.gain.exponentialRampToValueAtTime(gain, t + attack); g.gain.exponentialRampToValueAtTime(0.0001, t + dur);
    let node = o;
    if (filter) { const fl = c.createBiquadFilter(); fl.type = 'lowpass'; fl.frequency.value = filter; o.connect(fl); node = fl; }
    const p = c.createStereoPanner ? c.createStereoPanner() : null;
    node.connect(g);
    if (p) { p.pan.value = pan; g.connect(p); p.connect(this.master); } else g.connect(this.master);
    o.start(t); o.stop(t + dur + 0.05);
  }

  flap(pan = 0, strength = 1) { if (!this.ok()) return; this.noise(0.22, { type: 'lowpass', f0: 600 * strength, f1: 120, gain: 0.22 * strength, attack: 0.03, pan }); }
  thud(pan = 0) { if (!this.ok()) return; this.tone(0.25, { f0: 90, f1: 40, gain: 0.35, attack: 0.005, pan }); this.noise(0.18, { type: 'lowpass', f0: 400, f1: 80, gain: 0.2, pan }); }
  step(pan = 0) { if (!this.ok()) return; this.tone(0.08, { f0: 70, f1: 50, gain: 0.06, attack: 0.004, pan }); }
  fire(pan = 0, dur = 1.4) {
    if (!this.ok()) return;
    this.noise(dur, { type: 'bandpass', f0: 300, f1: 1400, q: 0.6, gain: 0.45, attack: 0.08, pan });
    this.noise(dur * 0.9, { type: 'lowpass', f0: 900, f1: 200, gain: 0.3, attack: 0.05, pan });
  }
  roar(pan = 0) {
    if (!this.ok()) return;
    this.tone(1.3, { type: 'sawtooth', f0: 110, f1: 70, gain: 0.22, attack: 0.12, pan, filter: 700 });
    this.tone(1.2, { type: 'sawtooth', f0: 165, f1: 95, gain: 0.12, attack: 0.15, pan, filter: 900 });
    this.noise(1.3, { type: 'bandpass', f0: 700, f1: 300, q: 1.5, gain: 0.25, attack: 0.1, pan });
  }
  growl(pan = 0) { if (!this.ok()) return; this.tone(0.7, { type: 'sawtooth', f0: 75, f1: 60, gain: 0.16, attack: 0.08, pan, filter: 400 }); }
  chirp(pan = 0) { if (!this.ok()) return; this.tone(0.18, { type: 'triangle', f0: 520, f1: 880, gain: 0.12, pan }); setTimeout(() => this.ok() && this.tone(0.2, { type: 'triangle', f0: 700, f1: 1050, gain: 0.1, pan }), 120); }
  purr(pan = 0) { if (!this.ok()) return; for (let i = 0; i < 6; i++) setTimeout(() => this.ok() && this.tone(0.12, { type: 'sawtooth', f0: 55, f1: 50, gain: 0.07, pan, filter: 250 }), i * 110); }
  snore(pan = 0) { if (!this.ok()) return; this.noise(1.4, { type: 'bandpass', f0: 180, f1: 120, q: 3, gain: 0.08, attack: 0.6, pan }); }
  whoosh(pan = 0) { if (!this.ok()) return; this.noise(0.5, { type: 'bandpass', f0: 400, f1: 1600, q: 0.8, gain: 0.15, attack: 0.1, pan }); }
  paper(pan = 0) { if (!this.ok()) return; this.noise(0.12, { type: 'highpass', f0: 2500, f1: 4000, gain: 0.12, attack: 0.005, pan }); }
  snap(pan = 0) { if (!this.ok()) return; this.tone(0.06, { type: 'square', f0: 300, f1: 120, gain: 0.1, attack: 0.002, pan, filter: 1200 }); }
}
