// Núcleo: mundo, dragón, comportamientos autónomos e interacción.
import { Application, Assets, Container } from 'pixi.js';
import { DragonView } from './dragonview.js';
import { Particles, Shadow, Orb, Paper, Bubble } from './fx.js';
import { Sound } from './sound.js';
import { createPlatform } from './platform.js';

const SIZES = { pequeno: 0.3, mediano: 0.42, grande: 0.58 };
const GX = 410, GY = 458;             // punto de apoyo del rig
const MOUTH = [578, 121];
const rand = (a, b) => a + Math.random() * (b - a);
const pick = (arr) => arr[Math.floor(Math.random() * arr.length)];
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
const now = () => performance.now() / 1000;

const GROUND = new Set(['nap', 'sit', 'lie', 'stretch', 'shake', 'yawn', 'roar', 'happy', 'idle', 'lookAround', 'investigate', 'sleep', 'reactClickGround']);
const MOODS = ['curioso', 'jugueton', 'perezoso', 'enfadado', 'contento', 'somnoliento'];
const MOOD_LABEL = { curioso: 'curioso', jugueton: 'juguetón', perezoso: 'perezoso', enfadado: 'enfadado', contento: 'contento', somnoliento: 'somnoliento' };
const MOOD_ANIM = { jugueton: 'contento', curioso: 'curioso', perezoso: 'perezoso', enfadado: 'enfadado', contento: 'contento', somnoliento: 'somnoliento' };

// Pesos de comportamiento por estado emocional
const WEIGHTS = {
  contento:    { idle: 3, wander: 4, sit: 3, stretch: 1, shake: 1, flyAround: 2, loop: 1, perch: 2, seekAttention: 1.5, playOrb: 1, lookAround: 2, happy: 1, glide: 1, run: 1 },
  curioso:     { idle: 1, wander: 3, lookAround: 4, investigate: 4, perch: 2, flyAround: 1.5, pushWindow: 1.5, seekAttention: 1, sit: 1, run: 0.5 },
  jugueton:    { chaseCursor: 4, playOrb: 3, run: 2, loop: 2, happy: 2, flyAround: 2, pushWindow: 1.5, fire: 1, seekAttention: 2, glide: 1 },
  perezoso:    { sit: 4, lie: 5, idle: 2, nap: 2, stretch: 1.5, lookAround: 1, wander: 0.5 },
  enfadado:    { fire: 3, roar: 2.5, wander: 2, idle: 1, flyAround: 1, shake: 1, pushWindow: 1.5 },
  somnoliento: { nap: 6, lie: 3, sit: 2, yawn: 2, idle: 1 },
};

export class Game {
  constructor(opts = {}) { this.opts = opts; }

  async start() {
    const P = this.P = createPlatform();
    this.scr = await P.init();
    this.settings = { ...(await P.settings()) };
    const app = this.app = new Application();
    await app.init({
      backgroundAlpha: 0, resizeTo: window, antialias: true, autoDensity: true,
      resolution: Math.min(2, window.devicePixelRatio || 1), preference: 'webgl', powerPreference: 'low-power',
    });
    (this.opts.mount || document.body).appendChild(app.canvas);
    app.canvas.style.position = 'fixed'; app.canvas.style.inset = '0'; app.canvas.style.zIndex = '10';
    const base = this.opts.assets || 'assets/';
    const [rig, body, wing] = await Promise.all([
      fetch(base + 'rig.json').then((r) => r.json()), Assets.load(base + 'body.webp'), Assets.load(base + 'wing.webp')]);
    this.rigData = rig;

    this.layers = {};
    for (const n of ['shadow', 'items', 'dragon', 'fx', 'ui']) { this.layers[n] = new Container(); app.stage.addChild(this.layers[n]); }
    this.dv = new DragonView(rig, { body, wing });
    this.dv.view.pivot.set(GX, GY);
    this.layers.dragon.addChild(this.dv.view);
    this.fx = new Particles(this.layers.fx);
    this.shadow = new Shadow(this.layers.shadow);
    this.orb = new Orb(this.layers.items);
    this.bubble = new Bubble(this.layers.ui);
    this.papers = [];
    this.sound = new Sound();
    this.sound.setVolume(this.settings.volume / 100);

    // estado del dragón
    this.d = {
      x: -400, y: 0, vx: 0, vy: 0, facing: 1, flip: 1, airborne: true, surface: null, present: false,
      held: null, dragging: false, busy: false,
    };
    this.mood = 'contento';
    this.energy = 0.8; this.irritation = 0; this.happiness = 0.6;
    this.recent = [];
    this.windows = []; this.surfaces = [];
    this.cursor = { x: -999, y: -999, moved: 0, lastMove: 0 };
    this.gen = null; this.genName = '';
    this.stayUntil = 0; this.moodUntil = now() + rand(20, 50);
    this.hidden = false; this.fullscreenHidden = false;
    this.clicks = []; this.petT = 0;

    app.ticker.maxFPS = 60;
    app.ticker.add((t) => this.tick(Math.min(0.05, t.deltaMS / 1000)));

    this.setupInput();
    await this.setupPlatformEvents();
    this.applySettings(this.settings, true);
    this.pollCursor();
    this.refreshWindows();
    setInterval(() => this.refreshWindows(), 2000);
    setInterval(() => { if (this.d.surface) this.refreshWindows(); }, 350);
    setInterval(() => this.checkFullscreen(), 3000);
    window.addEventListener('resize', async () => { this.scr = await P.refreshScreen(); });

    // entrada inicial
    setTimeout(() => this.enter(), this.opts.enterDelay ?? 800);
    return this;
  }

  // ---------------- utilidades ----------------
  get s() { return SIZES[this.settings.size] || 0.42; }
  get floorY() { return this.scr.work.bottom; }
  get W() { return this.scr.w; }
  get k() { return this.s / 0.42; } // factor de escala relativo
  pan() { return clamp((this.d.x / this.W) * 2 - 1, -1, 1) * 0.6; }
  mouthWorld() { const m = this.dv.mouth(); return this.dv.view.toGlobal(m); }
  headDir() {
    const a = this.dv.view.toGlobal(this.dv.rig.point('head', 482, 105));
    const b = this.dv.view.toGlobal(this.dv.rig.point('head', MOUTH[0], MOUTH[1]));
    const l = Math.hypot(b.x - a.x, b.y - a.y) || 1; return { x: (b.x - a.x) / l, y: (b.y - a.y) / l };
  }
  toLocal(p) { return this.dv.view.toLocal(p); }
  lookAtWorld(p) { this.dv.D.look = p ? this.toLocal(p) : null; }
  surfaceY(surf) { return surf ? surf.y : this.floorY; }
  surfaceRange(surf) {
    const m = 130 * this.k;
    return surf ? [surf.x1 + 40 * this.k, surf.x2 - 40 * this.k] : [m, this.W - m];
  }
  setMood(m) {
    if (this.mood === m) return; this.mood = m; this.dv.D.mood = MOOD_ANIM[m];
    this.moodUntil = now() + rand(25, 70);
    const sym = { curioso: '?', jugueton: '♪', enfadado: '💢', somnoliento: 'z', perezoso: '…', contento: '♥' }[m];
    if (this.d.present && sym) this.emote(sym);
    if (this.onMood) this.onMood(m);
  }
  emote(sym) {
    const p = this.headWorld();
    this.fx.text(sym, p.x, p.y - 30 * this.k, { size: 26 * this.k, vy: -25, life: 1.8 });
  }
  headWorld() { return this.dv.view.toGlobal(this.dv.rig.point('head', 520, 80)); }

  // ---------------- bucle principal ----------------
  tick(dt) {
    const d = this.d, D = this.dv.D;
    if (this.gen) {
      let r;
      try { r = this.gen.next(dt); } catch (e) { console.error(e); r = { done: true }; }
      if (r.done) { this.gen = null; this.genName = ''; }
    }
    if (!this.gen && d.present && !d.dragging) this.think();

    // volteo suave (giro)
    d.flip += (d.facing - d.flip) * Math.min(1, dt * 11);
    let fx = d.flip; if (Math.abs(fx) < 0.08) fx = 0.08 * Math.sign(fx || 1);
    const s = this.s;
    this.dv.view.scale.set(s * fx, s * (1 + 0.04 * (1 - Math.abs(d.flip))));
    this.dv.view.position.set(d.x, d.y);
    this.dv.update(dt);

    // sombra
    const fy = this.surfaceBelow(d.x, d.y);
    const alt = Math.max(0, fy - d.y);
    this.shadow.set(d.x + 20 * s * d.facing, fy - 2, s * (1 - Math.min(0.6, alt / 900)), d.present ? Math.max(0, 1 - alt / 700) : 0);

    for (const p of this.papers) {
      if (p.held && d.held === p) {
        const m = this.mouthWorld(); p.x = m.x + d.facing * 4 * this.k; p.y = m.y + 18 * this.k; p.rot = 0.35 * d.facing;
      }
      p.update(dt, this.floorY, this.W, s);
    }
    this.orb.update(dt, this.floorY, this.W, s);
    this.fx.update(dt);
    const hw = this.headWorld();
    this.bubble.update(dt, hw.x, hw.y - 40 * this.k);

    // estado interno
    this.irritation = Math.max(0, this.irritation - dt * 0.012);
    const sleeping = D.act === 'sleep';
    this.energy = clamp(this.energy + dt * (sleeping ? 0.012 : D.act === 'lie' || D.act === 'sit' ? 0.002 : -0.0016), 0, 1);
    if (this.petT > 0) this.petT -= dt;

    // FPS adaptativo
    const moving = d.airborne || D.act === 'walk' || D.act === 'run' || this.fx.active || this.orb.alive || this.papers.some((p) => !p.onFloor);
    this.app.ticker.maxFPS = sleeping && !this.fx.active ? 15 : moving ? 60 : 30;
  }

  surfaceBelow(x, y) {
    let best = this.floorY;
    for (const s of this.surfaces) if (x > s.x1 && x < s.x2 && s.y >= y - 2 && s.y < best) best = s.y;
    return best;
  }

  run(name, gen) {
    if (this.gen) { try { this.gen.return(); } catch {} }
    if (GROUND.has(name) && this.d.airborne && !this.d.dragging) {
      const inner = gen, self = this;
      gen = (function* () { yield* self.landSomewhere(); yield* inner; })();
    }
    this.gen = gen; this.genName = name;
    this.gen.next(0);
  }

  // ---------------- cerebro ----------------
  think() {
    const t = now();
    // estado emocional
    if (this.irritation > 0.55) this.setMood('enfadado');
    else if (this.energy < 0.22) this.setMood('somnoliento');
    else if (t > this.moodUntil) {
      const w = { contento: 3, curioso: 2.5, jugueton: 1.5 + this.happiness * 2 + (this.energy > 0.6 ? 1 : 0), perezoso: 1.5 + (1 - this.energy) * 2, enfadado: 0.2, somnoliento: this.energy < 0.4 ? 2 : 0 };
      this.setMood(this.weighted(w));
    }
    if (!this.settings.autonomy) { this.run('idle', this.bIdle(rand(3, 6), true)); return; }
    // marcharse
    if (this.settings.frequency !== 'siempre' && t > this.stayUntil && !this.d.held) { this.run('leave', this.bLeave()); return; }

    const W = { ...WEIGHTS[this.mood] };
    if (!this.settings.perch || !this.surfaces.length) delete W.perch;
    if (this.d.surface) { delete W.run; delete W.playOrb; delete W.chaseCursor; W.flyAround = (W.flyAround || 0) + 2; W.wander = (W.wander || 0) + 1; }
    if (!this.windows.length) delete W.pushWindow;
    if (this.d.held) { W.dropPaper = 4; W.flyAround = (W.flyAround || 1) + 1; }
    for (const r of this.recent) if (W[r]) W[r] *= 0.25; // evita repeticiones
    const name = this.weighted(W);
    this.recent.unshift(name); this.recent.length = Math.min(this.recent.length, 4);
    const fn = this['b' + name[0].toUpperCase() + name.slice(1)];
    this.run(name, fn ? fn.call(this) : this.bIdle(3));
  }

  weighted(w) {
    const e = Object.entries(w).filter(([, v]) => v > 0);
    let tot = e.reduce((a, [, v]) => a + v, 0), r = Math.random() * tot;
    for (const [k, v] of e) { if ((r -= v) <= 0) return k; }
    return e.length ? e[0][0] : 'idle';
  }

  // ---------------- primitivas ----------------
  *wait(t) { while (t > 0) t -= yield; }
  *act(name, t, resp = 8) { this.dv.setAct(name, resp); yield* this.wait(t); }
  *face(dir) { if (dir && dir !== this.d.facing) { this.d.facing = dir; yield* this.wait(0.2); } }

  *walkTo(x, run = false, maxT = 20) {
    const d = this.d, D = this.dv.D;
    const [a, b] = this.surfaceRange(d.surface);
    x = clamp(x, a, b);
    if (Math.abs(x - d.x) < 6) return;
    yield* this.face(Math.sign(x - d.x));
    this.dv.setAct(run ? 'run' : 'walk', run ? 12 : 10);
    const speed = (run ? 230 : 72) * this.k;
    const cyc = run ? 286 : 103;
    let stepAcc = 0, t = 0;
    while (Math.abs(x - d.x) > 3 && t < maxT) {
      const dt = yield; t += dt;
      const ease = Math.min(1, Math.abs(x - d.x) / (40 * this.k)) * 0.6 + 0.4;
      const step = Math.min(speed * ease * dt, Math.abs(x - d.x));
      d.x += Math.sign(x - d.x) * step;
      D.gaitPhase = (D.gaitPhase + step / this.s / cyc) % 1;
      stepAcc += step; if (stepAcc > 60 * this.k) { stepAcc = 0; this.sound.step(this.pan()); }
      if (d.surface && !this.surfaceStillValid()) { yield* this.fall(); return; }
    }
    this.dv.setAct('stand', 7);
  }

  *takeoff() {
    const d = this.d, D = this.dv.D;
    if (d.airborne) return;
    D.crouch = 1; this.dv.setAct('crouch', 12);
    yield* this.wait(0.28);
    this.sound.flap(this.pan(), 1.4);
    this.dust(d.x, d.y, 8);
    d.airborne = true; d.surface = null;
    d.vy = -380 * this.k; d.vx = d.facing * 40 * this.k;
    this.dv.setAct('hover', 14);
    let t = 0;
    while (t < 0.55) {
      const dt = yield; t += dt;
      d.vy += 420 * this.k * dt; d.x += d.vx * dt; d.y += d.vy * dt;
      this.advanceFlap(dt, 2.6);
    }
  }

  advanceFlap(dt, rate) {
    const D = this.dv.D, prev = D.flapPhase;
    D.flapPhase = (D.flapPhase + dt * rate) % 1;
    if (D.flapPhase < prev) this.sound.flap(this.pan(), 0.6);
  }

  *flyTo(tx, ty, { maxSpeed = 300, arrive = 14, maxT = 12, hover = false } = {}) {
    const d = this.d, D = this.dv.D;
    if (!d.airborne) yield* this.takeoff();
    maxSpeed *= this.k;
    let t = 0;
    while (t < maxT) {
      const dt = yield; t += dt;
      const dx = tx - d.x, dy = ty - d.y, dist = Math.hypot(dx, dy);
      if (dist < arrive * this.k) break;
      const sp = Math.min(maxSpeed, dist * 1.6 + 30);
      const vx = dx / dist * sp, vy = dy / dist * sp;
      const a = Math.min(1, dt * 2.4);
      d.vx += (vx - d.vx) * a; d.vy += (vy - d.vy) * a;
      d.x += d.vx * dt; d.y += d.vy * dt;
      if (Math.abs(d.vx) > 40) d.facing = Math.sign(d.vx);
      const speed = Math.hypot(d.vx, d.vy);
      D.pitch = clamp(d.vy / (900 * this.k), -0.3, 0.32) * (Math.abs(d.vx) / (speed + 1));
      let mode = 'fly';
      if (hover || speed < 90 * this.k) mode = 'hover';
      else if (d.vy > 40 * this.k && Math.abs(d.vx) > 140 * this.k) mode = 'glide';
      this.dv.setAct(mode, mode === 'glide' ? 4 : 9);
      if (mode !== 'glide') this.advanceFlap(dt, mode === 'hover' ? 2.4 : 1.5 + clamp(-d.vy / (300 * this.k), 0, 1));
      this.lookAtWorld({ x: d.x + d.vx * 2, y: d.y - 150 * this.k + d.vy });
    }
  }

  *landOn(surf, x) {
    const d = this.d, D = this.dv.D;
    let target = surf;
    const ty = () => (target ? target.y : this.floorY);
    const refresh = () => { if (target) { target = this.surfaces.find((s) => s.hwnd === target.hwnd) || null; return !!target; } return true; };
    const [a, b] = this.surfaceRange(target);
    x = clamp(x ?? d.x, a, b);
    yield* this.flyTo(x, ty() - 70 * this.k, { arrive: 18, maxSpeed: 260 });
    if (!refresh()) { yield* this.fall(); return; }
    // descenso suave
    this.dv.setAct('hover', 9);
    let t = 0;
    while (d.y < ty() && t < 3) {
      const dt = yield; t += dt;
      d.vy += (110 * this.k - d.vy) * Math.min(1, dt * 4); d.vx *= Math.pow(0.05, dt);
      d.x += d.vx * dt; d.y += d.vy * dt;
      this.advanceFlap(dt, 2.6);
      if (!refresh()) { yield* this.fall(); return; }
    }
    d.y = ty(); d.vx = d.vy = 0; d.airborne = false; d.surface = target;
    D.pitch = 0; D.crouch = 0.8;
    this.sound.thud(this.pan()); this.dust(d.x, d.y, 10);
    yield* this.act('crouch', 0.3, 14);
    this.dv.setAct('stand', 6);
    yield* this.wait(0.3);
  }

  *fall() {
    const d = this.d, D = this.dv.D;
    d.airborne = true; d.surface = null; d.held && this.dropHeld();
    this.dv.setAct('pounce', 8); D.pitch = 0.1;
    let t = 0;
    while (t < 5) {
      const dt = yield; t += dt;
      d.vy += 1300 * this.k * dt; d.x += d.vx * dt; d.y += d.vy * dt; d.vx *= Math.pow(0.4, dt);
      d.x = clamp(d.x, 60, this.W - 60);
      const fy = this.surfaceBelow(d.x, d.y - d.vy * dt - 1);
      if (d.y >= fy) {
        const surf = this.surfaces.find((s) => Math.abs(s.y - fy) < 1 && d.x > s.x1 && d.x < s.x2) || null;
        d.y = fy; d.airborne = false; d.surface = surf; d.vx = d.vy = 0; D.pitch = 0;
        this.sound.thud(this.pan()); this.dust(d.x, d.y, 14);
        D.crouch = 1; yield* this.act('crouch', 0.35, 16);
        if (this.mood !== 'enfadado' && Math.random() < 0.6) yield* this.act('shake', 0.8, 10);
        this.dv.setAct('stand', 7);
        return;
      }
    }
  }

  dust(x, y, n) {
    for (let i = 0; i < n; i++) this.fx.spawn('dust', x + rand(-90, 90) * this.k, y - rand(0, 8), rand(-80, 80) * this.k, rand(-40, -10), rand(0.5, 1), 0.4 * this.k, 1.2 * this.k, { alpha: 0.7, drag: 0.94 });
  }

  surfaceStillValid() { return !this.d.surface || this.surfaces.includes(this.d.surface); }

  // ---------------- comportamientos ----------------
  *bIdle(t = rand(3, 7), lookCursor = true) {
    this.dv.setAct('stand', 6);
    let tt = 0, nextLook = 0;
    while (tt < t) {
      const dt = yield; tt += dt; nextLook -= dt;
      if (lookCursor && this.cursorNear(450)) this.lookAtWorld(this.cursor);
      else if (nextLook <= 0) { nextLook = rand(1, 3); this.randomLook(); }
    }
  }
  randomLook() {
    const d = this.d;
    if (Math.random() < 0.3) { this.dv.D.look = null; return; }
    this.lookAtWorld({ x: d.x + d.facing * rand(100, 500) * this.k * (Math.random() < 0.2 ? -0.3 : 1), y: d.y - rand(50, 400) * this.k });
  }
  cursorNear(r) { return now() - this.cursor.lastMove < 2.5 && Math.hypot(this.cursor.x - this.d.x, this.cursor.y - (this.d.y - 120 * this.k)) < r * this.k; }

  *bLookAround() {
    if (Math.random() < 0.5) yield* this.face(-this.d.facing);
    this.dv.setAct('stand', 5);
    for (let i = 0; i < 4; i++) { this.randomLook(); yield* this.wait(rand(0.8, 1.6)); }
  }
  *bWander() {
    if (this.d.airborne) { yield* this.landOn(null); return; }
    const [a, b] = this.surfaceRange(this.d.surface);
    const span = Math.min(b - a, 600 * this.k);
    yield* this.walkTo(clamp(this.d.x + rand(-span, span), a, b));
    yield* this.bIdle(rand(1, 3));
  }
  *bRun() {
    const [a, b] = this.surfaceRange(this.d.surface);
    yield* this.walkTo(Math.random() < 0.5 ? a + rand(0, 200) : b - rand(0, 200), true);
    yield* this.bIdle(1.5);
  }
  *bSit() { yield* this.act('sit', 0.6, 5); yield* this.lookingWhile('sit', rand(6, 14)); }
  *bLie() { yield* this.act('lie', 0.8, 4); yield* this.lookingWhile('lie', rand(8, 18)); yield* this.act('stand', 0.7, 4); }
  *lookingWhile(act, t) {
    let tt = 0, nl = 0;
    this.dv.setAct(act, 4);
    while (tt < t) { const dt = yield; tt += dt; nl -= dt; if (this.cursorNear(400)) this.lookAtWorld(this.cursor); else if (nl <= 0) { nl = rand(1.5, 4); this.randomLook(); } }
  }
  *bNap() {
    this.dv.D.look = null;
    yield* this.act('lie', 1, 3);
    yield* this.act('sleep', 1.5, 2);
    const dur = rand(25, 70); let t = 0, sn = 2;
    this.dv.setAct('sleep', 2);
    while (t < dur && this.dv.D.act === 'sleep') {
      const dt = yield; t += dt; sn -= dt;
      if (sn <= 0) { sn = rand(2.5, 4); const h = this.headWorld(); this.fx.text('z', h.x + 20 * this.d.facing * this.k, h.y - 10, { size: rand(16, 26) * this.k, vy: -28, vx: 14 * this.d.facing, life: 2.6, color: 0xe8dcc8 }); if (Math.random() < 0.35) this.sound.snore(this.pan()); }
    }
    this.energy = Math.max(this.energy, 0.75);
    yield* this.act('lie', 1.2, 3);
    if (this.mood === 'somnoliento') this.setMood('contento');
    yield* this.bStretch();
  }
  *bStretch() { this.dv.setAct('stretch', 6); yield* this.wait(3.2); yield* this.act('shake', 0.7, 10); this.dv.setAct('stand', 6); }
  *bShake() { yield* this.act('shake', 1, 10); this.dv.setAct('stand', 6); yield* this.wait(0.4); }
  *bYawn() { yield* this.act('sit', 0.6, 5); this.dv.setAct('yawn', 6); this.sound.growl(this.pan()); yield* this.wait(2.2); yield* this.lookingWhile('sit', rand(3, 6)); }
  *bRoar() { this.dv.setAct('roar', 7); this.sound.roar(this.pan()); yield* this.wait(1.6); this.dv.setAct('stand', 6); yield* this.wait(0.5); }
  *bHappy() { this.dv.setAct('happy', 9); this.sound.chirp(this.pan()); this.emote('♪'); yield* this.wait(1.6); this.dv.setAct('stand', 6); }

  *bFire(target = null) {
    if (this.d.airborne) yield* this.landOn(this.d.surface);
    if (target) yield* this.face(Math.sign(target.x - this.d.x) || this.d.facing);
    else if (this.d.x < this.W * 0.25) yield* this.face(1); else if (this.d.x > this.W * 0.75) yield* this.face(-1);
    this.dv.D.look = target ? this.toLocal(target) : null;
    this.dv.setAct('fire', 9);
    yield* this.wait(0.6);
    this.sound.fire(this.pan(), 1.3);
    let t = 0;
    while (t < 1.3) {
      const dt = yield; t += dt;
      this.emitFire(dt, target);
    }
    yield* this.wait(0.5);
    for (let i = 0; i < 4; i++) { const m = this.mouthWorld(); this.fx.spawn('smoke', m.x, m.y, rand(-10, 10), rand(-40, -20), rand(1, 1.8), 0.3 * this.k, 1.4 * this.k, { alpha: 0.6 }); }
    this.dv.setAct('stand', 6);
    if (this.mood === 'enfadado') this.irritation *= 0.5;
  }
  emitFire(dt, target) {
    const m = this.mouthWorld(), dir = this.headDir(), k = this.k;
    const n = Math.ceil(dt * 90);
    for (let i = 0; i < n; i++) {
      const sp = rand(380, 560) * k, a = rand(-0.12, 0.12);
      const vx = (dir.x * Math.cos(a) - dir.y * Math.sin(a)) * sp, vy = (dir.x * Math.sin(a) + dir.y * Math.cos(a)) * sp;
      this.fx.spawn('fire', m.x + dir.x * 6, m.y + dir.y * 6, vx, vy - 20, rand(0.45, 0.75), 0.25 * k, rand(1.2, 1.9) * k, { drag: 0.955, g: -140, alpha: 0.9 });
    }
    if (Math.random() < 0.5) this.fx.spawn('spark', m.x, m.y, dir.x * rand(200, 400) * k + rand(-60, 60), dir.y * 300 * k + rand(-120, 20), rand(0.5, 1.1), 0.15 * k, 0.05, { g: 200, drag: 0.98 });
    // empujar documentos alcanzados por el fuego
    for (const p of this.papers) {
      if (p.held) continue;
      const rx = p.x - m.x, ry = p.y - m.y, along = rx * dir.x + ry * dir.y, perp = Math.abs(rx * dir.y - ry * dir.x);
      if (along > 0 && along < 260 * k && perp < 40 * k + along * 0.2) { p.vx += dir.x * 900 * dt; p.vy -= 500 * dt; p.vr += rand(-6, 6) * dt; p.singed = true; p.c.tint = 0xd8b890; }
    }
    if (this.orb.alive) { const rx = this.orb.x - m.x, ry = this.orb.y - m.y; if (Math.hypot(rx, ry) < 220 * k && rx * dir.x > 0) { this.orb.vx += dir.x * 800 * dt; this.orb.vy -= 300 * dt; } }
  }

  *bFlyAround() {
    const d = this.d;
    if (d.held && Math.random() < 0.5) { /* lleva el papel volando */ }
    yield* this.takeoff();
    const n = Math.floor(rand(2, 4));
    for (let i = 0; i < n; i++) {
      const tx = rand(150, this.W - 150), ty = rand(this.scr.work.top + 120 * this.k, this.floorY - 250 * this.k);
      yield* this.flyTo(tx, ty, { maxSpeed: rand(230, 340) });
      if (Math.random() < 0.3) yield* this.hoverFor(rand(0.8, 2));
    }
    yield* this.landSomewhere();
  }
  *hoverFor(t) {
    const d = this.d; this.dv.setAct('hover', 8); let tt = 0;
    while (tt < t) { const dt = yield; tt += dt; d.vx *= Math.pow(0.1, dt); d.vy *= Math.pow(0.1, dt); d.x += d.vx * dt; d.y += d.vy * dt + Math.sin(tt * 3) * 0.3; this.advanceFlap(dt, 2.4); if (this.cursorNear(500)) this.lookAtWorld(this.cursor); }
  }
  *landSomewhere() {
    if (this.settings.perch && this.surfaces.length && Math.random() < 0.35) {
      const s = pick(this.surfaces); yield* this.landOn(s, rand(s.x1 + 60, s.x2 - 60)); return;
    }
    yield* this.landOn(null, rand(200, this.W - 200));
  }
  *bLoop() {
    // dar vueltas en círculo
    yield* this.takeoff();
    const cx = clamp(this.d.x + rand(-200, 200), 300, this.W - 300), cy = clamp(this.floorY - rand(300, 450) * this.k, this.scr.work.top + 220, this.floorY - 250);
    const R = rand(140, 220) * this.k, dir = Math.random() < 0.5 ? 1 : -1;
    yield* this.flyTo(cx + R, cy, { maxSpeed: 320 });
    let ang = 0; const d = this.d, D = this.dv.D;
    const laps = rand(1, 2.2) * Math.PI * 2;
    while (Math.abs(ang) < laps) {
      const dt = yield; ang += dir * dt * 2.1;
      const nx = cx + Math.cos(ang) * R, ny = cy + Math.sin(ang) * R * 0.6;
      d.vx = (nx - d.x) / dt; d.vy = (ny - d.y) / dt; d.x = nx; d.y = ny;
      if (Math.abs(d.vx) > 20) d.facing = Math.sign(d.vx);
      D.pitch = clamp(d.vy / (900 * this.k), -0.3, 0.3);
      this.dv.setAct(d.vy > 60 ? 'glide' : 'fly', 7);
      this.advanceFlap(dt, 1.9);
    }
    d.vx = clamp(d.vx, -300, 300); d.vy = clamp(d.vy, -300, 300);
    yield* this.landSomewhere();
  }
  *bGlide() {
    // cruzar la pantalla planeando
    yield* this.takeoff();
    const left = this.d.x > this.W / 2;
    yield* this.flyTo(left ? this.W - 160 : 160, this.scr.work.top + rand(120, 250) * this.k, { maxSpeed: 300 });
    yield* this.flyTo(left ? 200 : this.W - 200, this.floorY - 220 * this.k, { maxSpeed: 340 });
    yield* this.landSomewhere();
  }
  *bPerch() {
    if (!this.surfaces.length) return;
    const s = pick(this.surfaces);
    yield* this.takeoff();
    yield* this.landOn(s, rand(s.x1 + 60 * this.k, s.x2 - 60 * this.k));
    if (this.d.surface && this.d.surface.hwnd === s.hwnd) { yield* this.lookingWhile(Math.random() < 0.5 ? 'sit' : 'stand', rand(5, 12)); if (Math.random() < 0.4) yield* this.bWander(); }
  }
  *bInvestigate() {
    // se acerca a curiosear el cursor
    const d = this.d;
    if (now() - this.cursor.lastMove > 8) { yield* this.bLookAround(); return; }
    const c = { ...this.cursor };
    if (!d.surface && c.y > this.floorY - 400 * this.k) {
      yield* this.walkTo(c.x - Math.sign(c.x - d.x) * 160 * this.k);
      yield* this.face(Math.sign(c.x - d.x) || d.facing);
    }
    this.dv.setAct('stand', 5);
    let t = 0;
    while (t < rand(3, 6)) { const dt = yield; t += dt; this.lookAtWorld(this.cursor); this.dv.D.mood = 'curioso'; }
    this.dv.D.mood = MOOD_ANIM[this.mood];
  }
  *bSeekAttention() {
    const d = this.d;
    if (d.surface) yield* this.landOn(null);
    yield* this.walkTo(clamp(this.cursor.x, 150, this.W - 150));
    yield* this.face(Math.sign(this.cursor.x - d.x) || d.facing);
    this.sound.chirp(this.pan()); this.emote('!');
    yield* this.act('happy', 1.4, 9);
    yield* this.lookingWhile('sit', rand(3, 6));
  }
  *bChaseCursor() {
    const d = this.d, D = this.dv.D;
    if (d.surface) { yield* this.takeoff(); }
    let t = 0, still = 0; const dur = rand(8, 16);
    let lx = this.cursor.x, ly = this.cursor.y;
    this.emote('♪');
    while (t < dur && still < 3) {
      const c = this.cursor;
      if (Math.hypot(c.x - lx, c.y - ly) < 3) still += 0.05; else still = 0;
      lx = c.x; ly = c.y;
      const high = c.y < this.floorY - 330 * this.k;
      if (high || d.airborne) {
        // persigue volando e intenta atraparlo
        if (!d.airborne) yield* this.takeoff();
        const tx = c.x - d.facing * 110 * this.k, ty = c.y + 150 * this.k;
        const dt = yield; t += dt;
        const dx = tx - d.x, dy = ty - d.y, dist = Math.hypot(dx, dy) || 1;
        const sp = Math.min(380 * this.k, dist * 3);
        d.vx += (dx / dist * sp - d.vx) * Math.min(1, dt * 3); d.vy += (dy / dist * sp - d.vy) * Math.min(1, dt * 3);
        d.x += d.vx * dt; d.y += d.vy * dt;
        if (Math.abs(c.x - d.x) > 30) d.facing = Math.sign(c.x - d.x);
        D.reach = dist < 90 * this.k; D.pitch = 0;
        this.dv.setAct('hover', 10); this.advanceFlap(dt, 2.6);
        this.lookAtWorld(c);
        if (D.reach && Math.random() < dt * 1.5) this.sound.snap(this.pan());
        if (!high && c.y > this.floorY - 200 * this.k) { D.reach = false; yield* this.landOn(null, c.x); }
      } else {
        const dt = yield; t += dt;
        const target = c.x - Math.sign(c.x - d.x) * 140 * this.k;
        const dist = target - d.x;
        if (Math.abs(dist) > 30 * this.k) {
          const run = Math.abs(dist) > 250 * this.k;
          if (Math.sign(dist) !== d.facing) d.facing = Math.sign(dist);
          this.dv.setAct(run ? 'run' : 'walk', 11);
          const sp = (run ? 240 : 90) * this.k, step = Math.min(sp * dt, Math.abs(dist));
          d.x = clamp(d.x + Math.sign(dist) * step, 100, this.W - 100);
          D.gaitPhase = (D.gaitPhase + step / this.s / (run ? 286 : 103)) % 1;
        } else {
          // ¡salto para atraparlo!
          this.lookAtWorld(c);
          yield* this.pounce(c);
        }
      }
    }
    D.reach = false;
    if (d.airborne) yield* this.landSomewhere();
    this.happiness = clamp(this.happiness + 0.15, 0, 1);
  }
  *pounce(target) {
    const d = this.d, D = this.dv.D;
    D.crouch = 1; this.dv.setAct('crouch', 14); yield* this.wait(0.25);
    d.airborne = true; const surf = d.surface; d.surface = null;
    d.vx = clamp((target.x - d.x) * 1.4, -420, 420); d.vy = -520 * this.k; D.pitch = -0.2;
    this.dv.setAct('pounce', 12); this.sound.snap(this.pan());
    let t = 0; const y0 = this.surfaceY(surf);
    while (t < 2) {
      const dt = yield; t += dt;
      d.vy += 1400 * this.k * dt; d.x = clamp(d.x + d.vx * dt, 80, this.W - 80); d.y += d.vy * dt; D.pitch = clamp(d.vy / 1500, -0.25, 0.3);
      if (d.vy > 0 && d.y >= y0) { d.y = y0; break; }
    }
    d.airborne = false; d.surface = surf; d.vx = d.vy = 0; D.pitch = 0;
    this.sound.thud(this.pan()); this.dust(d.x, d.y, 6);
    D.crouch = 0.8; yield* this.act('crouch', 0.25, 14);
  }

  *bPlayOrb() {
    const d = this.d;
    if (d.surface || d.airborne) yield* this.landOn(null);
    if (!this.orb.alive) { this.orb.spawn(clamp(d.x + d.facing * rand(200, 400) * this.k, 60, this.W - 60), this.scr.work.top + 40, rand(-80, 80), 0); yield* this.wait(1.2); }
    const hits = Math.floor(rand(2, 5));
    for (let i = 0; i < hits; i++) {
      // ir al orbe
      let t = 0;
      while (t < 8) {
        const off = d.facing * 150 * this.k;
        const tgt = this.orb.x - off;
        if (Math.abs(tgt - d.x) < 25 * this.k && Math.abs(this.orb.vx) < 300) break;
        yield* this.face(Math.sign(this.orb.x - d.x) || d.facing);
        this.dv.setAct(Math.abs(tgt - d.x) > 250 ? 'run' : 'walk', 11);
        const dt = yield; t += dt;
        const run = Math.abs(tgt - d.x) > 250, sp = (run ? 240 : 100) * this.k, step = Math.min(sp * dt, Math.abs(tgt - d.x));
        d.x = clamp(d.x + Math.sign(tgt - d.x) * step, 80, this.W - 80);
        this.dv.D.gaitPhase = (this.dv.D.gaitPhase + step / this.s / (run ? 286 : 103)) % 1;
        this.lookAtWorld(this.orb);
      }
      // golpe con la pata o salto encima
      if (Math.random() < 0.65) {
        this.dv.setAct('kick', 10); yield* this.wait(0.4);
        this.orb.vx = d.facing * rand(350, 600) * this.k; this.orb.vy = -rand(250, 520); this.sound.snap(this.pan());
        yield* this.wait(0.6);
      } else yield* this.pounce(this.orb);
      if (Math.random() < 0.3) { this.sound.chirp(this.pan()); this.emote('♪'); }
    }
    this.dv.setAct('stand', 6);
    this.happiness = clamp(this.happiness + 0.2, 0, 1);
    setTimeout(() => { if (this.genName !== 'playOrb') this.orb.kill(); }, 20000);
  }

  spawnPaper(x, y, label = '', flutter = true) {
    while (this.papers.length >= 4) { const p = this.papers.shift(); if (this.d.held === p) this.d.held = null; p.destroy(); }
    const p = new Paper(this.layers.items, label);
    p.x = x; p.y = y; p.flutter = flutter; p.vy = 20; p.rot = rand(-0.4, 0.4);
    this.papers.push(p); this.sound.paper(this.pan());
    return p;
  }
  freePaper() { return this.papers.find((p) => !p.held && p.alive); }
  *getPaper() {
    let p = this.freePaper();
    if (!p) return null;
    let t = 0; while (!p.onFloor && t < 8) { const dt = yield; t += dt; this.lookAtWorld(p); }
    return p;
  }
  *goToPaper(p, gap) {
    const d = this.d;
    if (d.surface || d.airborne) yield* this.landOn(null, p.x - 150 * this.k);
    const side = p.x > d.x ? 1 : -1;
    yield* this.walkTo(p.x - side * gap * this.k, false);
    yield* this.face(side);
  }
  *bPaperKick() {
    const p = yield* this.getPaper(); if (!p) return;
    yield* this.goToPaper(p, 170);
    this.lookAtWorld(p);
    this.dv.setAct('kick', 10); yield* this.wait(0.42);
    if (Math.abs(p.x - this.d.x) < 260 * this.k && !p.held) {
      p.vx = this.d.facing * rand(380, 650) * this.k; p.vy = -rand(380, 600); p.vr = this.d.facing * rand(6, 12); p.onFloor = false;
      this.sound.paper(this.pan()); this.sound.snap(this.pan());
    }
    yield* this.wait(0.7);
    this.dv.setAct('stand', 6);
    if (this.mood === 'jugueton' && Math.random() < 0.5) { this.sound.chirp(this.pan()); this.emote('♪'); }
    yield* this.bIdle(rand(1, 2.5));
  }
  *bPaperGrab() {
    const p = yield* this.getPaper(); if (!p) return;
    yield* this.goToPaper(p, 168);
    this.dv.setAct('grab', 8); yield* this.wait(0.6);
    if (!p.held && Math.abs(p.x - this.mouthWorld().x) < 120 * this.k) { p.held = true; this.d.held = p; this.sound.paper(this.pan()); }
    yield* this.wait(0.6);
    this.dv.setAct('stand', 6);
    if (p.label) this.bubble.show('📄 ' + p.label, 3);
    yield* this.bWander();
    if (Math.random() < 0.5) yield* this.bDropPaper();
  }
  *bDropPaper() {
    if (!this.d.held) return;
    if (this.d.airborne && Math.random() < 0.5) { this.dropHeld(); yield* this.wait(0.5); return; }
    if (this.d.airborne) yield* this.landOn(this.d.surface);
    this.dv.setAct('grab', 8); yield* this.wait(0.55);
    this.dropHeld(); yield* this.wait(0.6); this.dv.setAct('stand', 6);
  }
  dropHeld() { const p = this.d.held; if (!p) return; p.held = false; p.vy = 0; p.vx = this.d.vx * 0.5; p.vr = rand(-2, 2); this.d.held = null; this.sound.paper(this.pan()); }
  *bPaperPush() {
    const p = yield* this.getPaper(); if (!p) return;
    yield* this.goToPaper(p, 175);
    const d = this.d, D = this.dv.D;
    const dist = rand(150, 320) * this.k, dir = d.facing; let moved = 0;
    this.dv.setAct('walk', 9);
    while (moved < dist) {
      const dt = yield; const step = 45 * this.k * dt; moved += step;
      d.x += dir * step; D.gaitPhase = (D.gaitPhase + step / this.s / 103) % 1;
      const m = this.mouthWorld(); p.x = m.x + dir * 22 * this.k; p.vx = 0;
      this.lookAtWorld({ x: p.x, y: p.y + 10 });
      if (d.x < 120 || d.x > this.W - 120) break;
    }
    this.dv.setAct('stand', 6); yield* this.wait(0.8);
  }

  *bPushWindow() {
    const d = this.d, D = this.dv.D;
    const cands = this.windows.filter((w) => !w.maximized && w.h > 150 && w.y > 40 && w.y + 140 < this.floorY);
    if (!cands.length) { yield* this.bPlayOrb(); return; }
    const w = pick(cands);
    const fromLeft = w.x > 260 ? (w.x + w.w < this.W - 260 ? Math.random() < 0.5 : true) : false;
    const dir = fromLeft ? 1 : -1;
    const edgeX = fromLeft ? w.x : w.x + w.w;
    const hy = w.y + Math.min(180, w.h * 0.55);
    yield* this.takeoff();
    yield* this.flyTo(edgeX - dir * 150 * this.k, hy + 110 * this.k, { maxSpeed: 320 });
    d.facing = dir;
    D.reach = true;
    const real = this.settings.real_windows;
    let t = 0, acc = 0, total = 0;
    while (t < 1.8) {
      const dt = yield; t += dt; acc += dt;
      this.dv.setAct('hover', 10); this.advanceFlap(dt, 3);
      d.vx = 0; d.vy = 0;
      if (acc > 0.12) {
        acc = 0;
        if (real) {
          const ok = await_(this.P.moveWindow(w.hwnd, dir * 9, 0));
          ok.then((r) => { if (r) { d.x += dir * 9; total += 9; } });
        } else if (Math.random() < 0.3) this.sound.snap(this.pan());
      }
    }
    D.reach = false;
    if (!real && !this._toldReal) {
      this._toldReal = true;
      this.bubble.show('¡No se mueve! (Actívalo en el menú: Interacción con Windows)', 4);
    }
    if (real && total > 0) { this.sound.chirp(this.pan()); this.happiness = clamp(this.happiness + 0.1, 0, 1); }
    yield* this.hoverFor(0.6);
    yield* this.landSomewhere();
  }

  *bLeave() {
    const d = this.d;
    if (d.held) this.dropHeld();
    yield* this.takeoff();
    const right = d.x > this.W / 2;
    yield* this.flyTo(right ? this.W + 400 : -400, this.scr.work.top + rand(-100, 150), { maxSpeed: 380, arrive: 40, maxT: 8 });
    this.goAway();
  }

  // ---------------- presencia ----------------
  stayDuration() { return { baja: rand(120, 240), normal: rand(180, 420), alta: rand(300, 600), siempre: 1e9 }[this.settings.frequency] ?? 300; }
  awayDuration() { return { baja: rand(900, 1800), normal: rand(240, 600), alta: rand(60, 180), siempre: 2 }[this.settings.frequency] ?? 300; }

  goAway() {
    const d = this.d;
    d.present = false; this.gen = null; this.genName = '';
    this.orb.kill(); this.fx.clear();
    this.updateRunning();
    clearTimeout(this.awayTimer);
    const away = this.awayDuration() * 1000;
    // a veces cruza la pantalla volando mientras está fuera
    if (this.settings.autonomy && Math.random() < 0.4 && away > 60000) setTimeout(() => this.flyby(), away * rand(0.3, 0.6));
    this.awayTimer = setTimeout(() => this.enter(), away);
  }
  flyby() {
    if (this.d.present || this.hidden || this.settings.paused) return;
    const d = this.d, right = Math.random() < 0.5;
    Object.assign(d, { present: true, airborne: true, surface: null, x: right ? -300 : this.W + 300, y: this.scr.work.top + rand(100, 300), vx: 0, vy: 0, facing: right ? 1 : -1 });
    d.flip = d.facing;
    this.updateRunning();
    const self = this;
    this.run('flyby', (function* () {
      yield* self.flyTo(right ? self.W + 400 : -400, self.scr.work.top + rand(80, 350), { maxSpeed: 420, arrive: 40, maxT: 10 });
      d.present = false; self.updateRunning();
    })());
  }
  enter() {
    if (this.d.present) return;
    if (this.hidden || this.settings.paused) { this.pendingEnter = true; return; }
    const d = this.d, fromLeft = Math.random() < 0.5;
    Object.assign(d, { present: true, airborne: true, surface: null, x: fromLeft ? -300 : this.W + 300, y: this.scr.work.top + rand(60, 260), vx: 0, vy: 0, facing: fromLeft ? 1 : -1 });
    d.flip = d.facing; this.dv.first = true;
    this.stayUntil = now() + this.stayDuration();
    this.updateRunning();
    const self = this;
    this.run('enter', (function* () {
      yield* self.flyTo(rand(self.W * 0.25, self.W * 0.75), self.floorY - rand(250, 400) * self.k, { maxSpeed: 340 });
      if (Math.random() < 0.4) yield* self.hoverFor(1);
      yield* self.landSomewhere();
      if (Math.random() < 0.5) yield* self.bRoar(); else yield* self.bShake();
    })());
  }
  summon() {
    if (!this.d.present) { clearTimeout(this.awayTimer); this.enter(); return; }
    this.stayUntil = now() + this.stayDuration();
    const self = this;
    this.run('summon', (function* () { yield* self.bSeekAttention(); })());
  }

  // ---------------- ventanas reales (sólo lectura salvo opción) ----------------
  async refreshWindows() {
    if (!this.d.present || this.hidden || this.settings.paused) return;
    if (!this.settings.perch && !this.settings.real_windows && !this.windows.length) { this.surfaces = []; return; }
    let wins = [];
    try { wins = await this.P.windows(); } catch { wins = []; }
    this.windows = wins;
    const old = this.surfaces, cur = this.d.surface;
    const surfs = [];
    if (this.settings.perch) {
      const minW = 220 * this.k, hgt = 230 * this.k;
      for (let i = 0; i < wins.length; i++) {
        const w = wins[i];
        if (w.maximized || w.y < hgt || w.y > this.floorY - 60 || w.w < minW) continue;
        let best = null, run = null;
        for (let x = Math.max(0, w.x + 20); x <= Math.min(this.W, w.x + w.w - 20); x += 16) {
          const covered = wins.slice(0, i).some((o) => x >= o.x && x <= o.x + o.w && w.y - 6 >= o.y && w.y - 6 <= o.y + o.h);
          if (!covered) { if (!run) run = { x1: x, x2: x }; else run.x2 = x; } else run = null;
          if (run && (!best || run.x2 - run.x1 > best.x2 - best.x1)) best = { ...run };
        }
        if (best && best.x2 - best.x1 >= minW) surfs.push({ hwnd: w.hwnd, x1: best.x1, x2: best.x2, y: w.y, wx: w.x, title: w.title });
      }
    }
    // mantener la identidad del objeto de la superficie actual para seguirla si la ventana se mueve
    if (cur) {
      const n = surfs.find((s) => s.hwnd === cur.hwnd);
      if (n) {
        const dx = n.wx - cur.wx;
        Object.assign(cur, n);
        surfs[surfs.indexOf(n)] = cur;
        if (!this.d.airborne) { this.d.y = cur.y; this.d.x += dx; }   // viaja con la ventana
        if (!this.d.airborne && (this.d.x < cur.x1 - 30 || this.d.x > cur.x2 + 30)) { this.surfaces = surfs; this.d.surface = null; this.run('fall', this.fall()); return; }
      } else if (!this.d.airborne) {
        this.surfaces = surfs; this.d.surface = null;
        this.run('fall', this.fall()); return;
      }
    }
    this.surfaces = surfs;
    void old;
  }

  async checkFullscreen() {
    if (!this.P.fullscreen) return;
    let fs = false; try { fs = await this.P.fullscreen(); } catch {}
    if (fs !== this.fullscreenHidden) { this.fullscreenHidden = fs; this.updateRunning(); }
  }

  // ---------------- entrada ----------------
  async pollCursor() {
    const loop = async () => {
      let delay = 50;
      if (this.running()) {
        try {
          const c = await this.P.cursor();
          if (Math.hypot(c.x - this.cursor.x, c.y - this.cursor.y) > 2) { this.cursor.lastMove = now(); }
          this.cursor.x = c.x; this.cursor.y = c.y;
          const hit = this.d.dragging || this.menuOpen() || this.hitTest(c.x, c.y);
          this.P.clickThrough(!hit);
          this.hovering = hit && !this.d.dragging;
          if (this.hovering && this.cursor.lastMove > now() - 0.2 && !this.d.airborne) this.pet(0.05);
          if (this.dv.D.act === 'sleep') delay = 200;
        } catch { delay = 500; }
      } else { this.P.clickThrough(true); delay = 400; }
      setTimeout(loop, delay);
    };
    loop();
  }
  menuOpen() {
    const m = document.getElementById('ctxmenu'), h = document.getElementById('help');
    const inside = (el) => { if (!el || el.style.display === 'none') return false; const r = el.getBoundingClientRect(); return this.cursor.x >= r.left && this.cursor.x <= r.right && this.cursor.y >= r.top && this.cursor.y <= r.bottom; };
    return inside(m) || inside(h);
  }
  hitTest(x, y) {
    if (!this.d.present) return false;
    const p = this.toLocal({ x, y });
    const rig = this.dv.rig, r2 = 8 * 8;
    if (p.x < -200 || p.x > 900 || p.y < -300 || p.y > 700) return false;
    for (const key of ['body', 'wing']) {
      const L = rig.layers[key]; const a = L.out.data;
      for (let i = 0; i < a.length; i += 2) { const dx = a[i] - p.x, dy = a[i + 1] - p.y; if (dx * dx + dy * dy < r2) return true; }
    }
    return false;
  }
  pet(amount) {
    this.petAcc = (this.petAcc || 0) + amount;
    if (this.petAcc > 1.2 && this.petT <= 0 && !this.d.dragging) {
      this.petAcc = 0; this.petT = 6;
      this.happiness = clamp(this.happiness + 0.15, 0, 1); this.irritation = Math.max(0, this.irritation - 0.2);
      this.sound.purr(this.pan()); this.emote('♥');
      if (this.dv.D.act === 'stand' && !this.gen) this.dv.D.mood = 'contento';
    }
  }

  setupInput() {
    const c = this.app.canvas;
    let down = null;
    c.addEventListener('contextmenu', (e) => { e.preventDefault(); if (this.hitTest(e.clientX, e.clientY)) this.openMenu(e.clientX, e.clientY); });
    c.addEventListener('pointerdown', (e) => {
      if (e.button !== 0) return;
      this.sound.ensure();
      this.closeMenu();
      if (!this.hitTest(e.clientX, e.clientY)) return;
      down = { x: e.clientX, y: e.clientY, t: now(), ox: this.d.x - e.clientX, oy: this.d.y - e.clientY };
      c.setPointerCapture(e.pointerId);
    });
    c.addEventListener('pointermove', (e) => {
      this.cursor.x = e.clientX; this.cursor.y = e.clientY; this.cursor.lastMove = now();
      if (!down) return;
      if (!this.d.dragging && Math.hypot(e.clientX - down.x, e.clientY - down.y) > 7) this.startDrag();
      if (this.d.dragging) {
        const nx = e.clientX + down.ox, ny = e.clientY + down.oy;
        this.dragV = { x: (nx - this.d.x) * 30, y: (ny - this.d.y) * 30 };
        this.d.x = nx; this.d.y = ny;
      }
    });
    c.addEventListener('pointerup', (e) => {
      if (!down) return;
      const wasDrag = this.d.dragging;
      down = null;
      if (wasDrag) this.endDrag(); else this.onClick(e.clientX, e.clientY);
    });
  }
  startDrag() {
    const d = this.d;
    d.dragging = true; d.airborne = true; d.surface = null;
    this.run('dragged', (function* (self) { self.dv.setAct('dangle', 10); self.sound.growl(self.pan()); while (true) { yield; self.lookAtWorld({ x: self.cursor.x, y: self.cursor.y + 200 }); } })(this));
    // el punto de agarre es el lomo: centramos ligeramente
  }
  endDrag() {
    const d = this.d; d.dragging = false;
    const v = this.dragV || { x: 0, y: 0 };
    d.vx = clamp(v.x, -600, 600); d.vy = clamp(v.y, -600, 600);
    const high = d.y < this.floorY - 260 * this.k;
    const self = this;
    if (high && Math.random() < 0.6) {
      this.run('flyFromDrag', (function* () { self.dv.setAct('hover', 10); yield* self.hoverFor(0.8); yield* self.landSomewhere(); })());
    } else this.run('fall', this.fall());
    this.irritation = clamp(this.irritation + 0.1, 0, 1);
  }
  onClick(x, y) {
    const t = now(), d = this.d;
    this.clicks = this.clicks.filter((c) => t - c < 2.5); this.clicks.push(t);
    const self = this;
    if (this.clicks.length >= 2 && t - this.clicks[this.clicks.length - 2] < 0.35) {
      // doble clic: ¡a volar!
      this.clicks = [];
      this.run('flyAround', this.bFlyAround()); return;
    }
    this.irritation = clamp(this.irritation + 0.13, 0, 1);
    if (this.dv.D.act === 'sleep') {
      this.irritation += 0.2; this.sound.growl(this.pan()); this.emote('💢');
      this.run('wake', (function* () { yield* self.act('lie', 0.8, 4); yield* self.act('stand', 0.6, 5); self.lookAtWorld({ x, y }); yield* self.wait(1); })());
      return;
    }
    if (this.irritation > 0.6 || this.clicks.length >= 4) {
      this.setMood('enfadado'); this.clicks = [];
      this.run('fire', (function* () { self.sound.growl(self.pan()); yield* self.bFire({ x, y }); })());
      return;
    }
    // curiosidad / alegría
    this.run('reactClick', (function* () {
      if (!d.airborne) yield* self.face(Math.sign(x - d.x) || d.facing);
      self.lookAtWorld({ x, y });
      if (self.mood === 'jugueton' || self.mood === 'contento') { self.sound.chirp(self.pan()); yield* self.act(d.airborne ? 'hover' : 'happy', 1.4, 9); }
      else { self.dv.D.mood = 'curioso'; self.sound.chirp(self.pan()); self.emote('?'); yield* self.wait(1.5); self.dv.D.mood = MOOD_ANIM[self.mood]; }
      if (d.airborne) yield* self.landSomewhere();
    })());
  }

  openMenu(x, y) {
    let m = document.getElementById('ctxmenu');
    if (!m) return;
    m.style.display = 'block';
    const r = m.getBoundingClientRect();
    m.style.left = Math.min(x, window.innerWidth - r.width - 8) + 'px';
    m.style.top = Math.min(y, window.innerHeight - r.height - 8) + 'px';
    this.P.clickThrough(false);
  }
  closeMenu() { const m = document.getElementById('ctxmenu'); if (m) m.style.display = 'none'; }
  command(cmd) {
    this.closeMenu();
    const self = this;
    switch (cmd) {
      case 'hide': this.P.setSetting('visible', false); break;
      case 'pause': this.P.setSetting('paused', true); break;
      case 'sleep': this.run('nap', this.bNap()); break;
      case 'play': this.setMood('jugueton'); this.run('playOrb', this.bPlayOrb()); break;
      case 'fire': this.run('fire', this.bFire()); break;
      case 'fly': this.run('flyAround', this.bFlyAround()); break;
      case 'chase': this.setMood('jugueton'); this.run('chaseCursor', this.bChaseCursor()); break;
      case 'loop': this.run('loop', this.bLoop()); break;
      case 'leave': this.run('leave', this.bLeave()); break;
      case 'help': this.showHelp(); break;
      case 'quit': this.P.quit(); break;
      default: {
        const fn = this['b' + cmd[0].toUpperCase() + cmd.slice(1)];
        if (fn && this.d.present) this.run(cmd, fn.call(this));
      }
    }
    void self;
  }
  showHelp() { const h = document.getElementById('help'); if (h) { h.style.display = 'block'; } }

  async setupPlatformEvents() {
    const P = this.P;
    await P.on('settings', (s) => this.applySettings(s));
    await P.on('summon', () => this.summon());
    await P.on('help', () => this.showHelp());
    await P.onDrop(({ paths, x, y }) => {
      const name = String(paths[0] || '').split(/[\\/]/).pop();
      // Documento real soltado sobre el dragón: sólo se representa, nunca se modifica el archivo.
      const p = this.spawnPaper(x, y, name, false); p.vy = 0;
      this.bubble.show('📄 ' + name + (paths.length > 1 ? ` (+${paths.length - 1})` : ''), 3);
      if (this.d.present) { this.setMood('curioso'); this.run('paperGrab', this.bPaperGrab()); }
    });
  }

  applySettings(s, initial = false) {
    const prev = this.settings;
    this.settings = { ...s };
    this.sound.setVolume((s.volume ?? 50) / 100);
    this.hidden = !s.visible;
    if (prev && prev.size !== s.size && !initial) { /* el tamaño cambia en caliente */ }
    if (!initial && prev.frequency !== s.frequency) this.stayUntil = Math.min(this.stayUntil, now() + this.stayDuration());
    if (s.frequency === 'siempre' && !this.d.present && !initial) { clearTimeout(this.awayTimer); this.enter(); }
    this.updateRunning();
    if (!this.hidden && !s.paused && this.pendingEnter) { this.pendingEnter = false; this.enter(); }
  }

  running() { return this.d.present && !this.hidden && !this.settings.paused && !this.fullscreenHidden; }
  updateRunning() {
    const on = this.running();
    this.app.stage.visible = this.d.present && !this.hidden && !this.fullscreenHidden;
    if (on) { this.app.ticker.start(); }
    else {
      this.app.ticker.stop();
      this.app.render();
      this.P.clickThrough(true);
      if (!this.d.present || this.hidden) this.sound.suspend();
    }
  }
}

// pequeña utilidad para usar promesas dentro de generadores sin bloquear
function await_(p) { return Promise.resolve(p).catch(() => false); }
