// Menú contextual (clic derecho sobre el dragón) y panel de instrucciones.
export function buildUI(game) {
  const css = document.createElement('style');
  css.textContent = `
  #ctxmenu{position:fixed;display:none;z-index:50;min-width:210px;background:rgba(40,28,20,.96);border:1px solid #8a6440;border-radius:10px;padding:6px;box-shadow:0 10px 30px rgba(0,0,0,.45);font:13px 'Segoe UI',sans-serif;color:#f1e3cf;backdrop-filter:blur(6px)}
  #ctxmenu .t{font:italic 15px Georgia,serif;color:#e7b46c;padding:6px 10px 8px;border-bottom:1px solid #5b4029;margin-bottom:4px}
  #ctxmenu button{display:block;width:100%;text-align:left;background:none;border:0;color:inherit;font:inherit;padding:7px 10px;border-radius:6px;cursor:pointer}
  #ctxmenu button:hover{background:#6b4a2c}
  #ctxmenu hr{border:0;border-top:1px solid #5b4029;margin:4px 0}
  #help{position:fixed;display:none;z-index:50;right:24px;bottom:70px;width:380px;background:rgba(40,28,20,.97);border:1px solid #8a6440;border-radius:14px;padding:18px 20px;font:13.5px/1.5 'Segoe UI',sans-serif;color:#f1e3cf;box-shadow:0 12px 40px rgba(0,0,0,.5)}
  #help h2{margin:0 0 8px;font:italic 20px Georgia,serif;color:#e7b46c}
  #help li{margin:3px 0} #help .x{position:absolute;right:12px;top:10px;background:none;border:0;color:#e7b46c;font-size:20px;cursor:pointer}
  `;
  document.head.appendChild(css);
  const m = document.createElement('div'); m.id = 'ctxmenu';
  const items = [['t', 'Ember'], ['fly', '🪽 Volar'], ['loop', '🌀 Dar vueltas'], ['chase', '🖱️ Perseguir el cursor'], ['play', '🔮 Jugar con el orbe'], ['fire', '🔥 Escupir fuego'], ['sleep', '💤 Dormir'], ['hr'], ['leave', '👋 Que se vaya un rato'],
    ['pause', '⏸ Pausar'], ['hide', '🙈 Ocultar'], ['help', '❔ Instrucciones'], ['hr'], ['quit', '✖ Cerrar la aplicación']];
  for (const [k, l] of items) {
    if (k === 't') { const d = document.createElement('div'); d.className = 't'; d.textContent = l; m.appendChild(d); continue; }
    if (k === 'hr') { m.appendChild(document.createElement('hr')); continue; }
    const b = document.createElement('button'); b.textContent = l; b.onclick = () => game.command(k); m.appendChild(b);
  }
  document.body.appendChild(m);
  const h = document.createElement('div'); h.id = 'help';
  h.innerHTML = `<button class="x" title="Cerrar">×</button><h2>Ember, tu dragón</h2>
  <ul>
  <li><b>Clic</b> sobre él: reacciona (curiosidad o alegría). Muchos clics seguidos… se enfada.</li>
  <li><b>Doble clic</b>: echa a volar.</li>
  <li><b>Arrástralo</b> para cogerlo; al soltarlo cae o sale volando.</li>
  <li><b>Pasa el ratón despacio</b> por encima para acariciarlo.</li>
  <li><b>Clic derecho</b>: menú rápido (volar, jugar, fuego, dormir…).</li>
  <li><b>Suelta un archivo</b> sobre él y lo atrapará (sólo visualmente: tus archivos nunca se tocan).</li>
  <li>El <b>icono de la bandeja</b> (junto al reloj) tiene todos los ajustes: mostrar/ocultar, pausa, autonomía, frecuencia, volumen, tamaño y salir.</li>
  </ul>`;
  h.querySelector('.x').onclick = () => { h.style.display = 'none'; };
  document.body.appendChild(h);
}
