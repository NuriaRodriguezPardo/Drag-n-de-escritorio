// Vista del dragón: rig + animador + párpado + brillo de ojos.
import { Container, Graphics, Matrix, Sprite, Texture } from 'pixi.js';
import { Rig } from './rig.js';
import { Animator } from './anim.js';

let glowTex = null;
export function radialTexture(size = 64, stops = [[0, 'rgba(255,255,255,1)'], [1, 'rgba(255,255,255,0)']]) {
  const c = document.createElement('canvas'); c.width = c.height = size;
  const g = c.getContext('2d');
  const gr = g.createRadialGradient(size / 2, size / 2, 0, size / 2, size / 2, size / 2);
  for (const [o, col] of stops) gr.addColorStop(o, col);
  g.fillStyle = gr; g.fillRect(0, 0, size, size);
  return Texture.from(c);
}

export class DragonView {
  constructor(rigData, textures) {
    this.rig = new Rig(rigData, textures);
    this.anim = new Animator(this.rig);
    this.view = new Container();
    this.view.addChild(this.rig.view);
    const [ex, ey] = rigData.points.eye;
    // párpado (en el espacio de la cabeza)
    this.headAttach = new Container();
    this.rig.view.addChild(this.headAttach);
    this.lid = new Graphics();
    this.lid.ellipse(0, 4.2, 6.6, 4.4).fill(0x4a2e1c);
    this.lid.moveTo(-6.4, 4.6).quadraticCurveTo(0, 9.6, 6.4, 4.6).stroke({ width: 1.1, color: 0x26160c, alpha: 0.9 });
    this.lid.position.set(ex, ey - 4.2);
    this.lid.rotation = 0.18;
    this.lid.scale.y = 0;
    if (!glowTex) glowTex = radialTexture(64, [[0, 'rgba(255,190,60,0.95)'], [0.35, 'rgba(255,120,20,0.45)'], [1, 'rgba(255,80,0,0)']]);
    this.glow = new Sprite(glowTex);
    this.glow.anchor.set(0.5); this.glow.position.set(ex, ey); this.glow.scale.set(0.45);
    this.glow.blendMode = 'add'; this.glow.alpha = 0;
    this.headAttach.addChild(this.glow, this.lid);
    this._hm = new Matrix();

    this.D = {
      t: 0, act: 'stand', actT: 0, gaitPhase: 0, flapPhase: 0, flapAmp: 1, pitch: 0,
      look: null, mood: 'contento', breathRate: 0.28, wingFold: 0.25, blink: 0,
    };
    this.nextBlink = 2;
    this.blinkT = -1;
    this.response = 9;
    this.first = true;
  }

  setAct(name, response = 9) {
    if (this.D.act !== name) { this.D.act = name; this.D.actT = 0; }
    this.response = response;
  }

  update(dt) {
    const D = this.D;
    D.t += dt; D.actT += dt;
    // parpadeo
    let lid = 0;
    if (D.act === 'sleep') lid = 1;
    else {
      this.nextBlink -= dt;
      if (this.nextBlink <= 0 && this.blinkT < 0) { this.blinkT = 0; this.nextBlink = 1.8 + Math.random() * 4.5; if (Math.random() < 0.2) this.nextBlink = 0.25; }
      if (this.blinkT >= 0) { this.blinkT += dt; lid = Math.sin(Math.min(1, this.blinkT / 0.16) * Math.PI); if (this.blinkT > 0.16) this.blinkT = -1; }
      if (D.mood === 'somnoliento') lid = Math.max(lid, 0.55 + 0.1 * Math.sin(D.t * 0.7));
      if (D.mood === 'perezoso') lid = Math.max(lid, 0.3);
    }
    D.blink += (lid - D.blink) * Math.min(1, dt * 30);
    this.lid.scale.y = D.blink;
    const wantGlow = D.mood === 'enfadado' || D.act === 'fire' ? 1 : 0;
    this.glow.alpha += (wantGlow * (0.7 + 0.3 * Math.sin(D.t * 9)) - this.glow.alpha) * Math.min(1, dt * 6);

    this.anim.apply(D, dt);
    if (this.first) { this.rig.snap(); this.first = false; }
    this.rig.update(dt, this.response);
    const m = this.rig.matrix('head');
    this._hm.set(m[0], m[1], m[2], m[3], m[4], m[5]);
    this.headAttach.setFromMatrix(this._hm);
  }

  // punto de un hueso en coordenadas locales del view
  bonePoint(bone, x, y) { return this.rig.point(bone, x, y); }
  mouth() { const [x, y] = this.rig.data.points.mouth; return this.rig.point('head', x, y); }
  nostril() { const [x, y] = this.rig.data.points.nostril; return this.rig.point('head', x, y); }
  headAngle() { return this.rig.boneAngle('head') + this.rig.bones[this.rig.idx.head].restAngle; }
}
