// Puente con el sistema. En Tauri usa los comandos nativos; en un navegador (vista previa)
// simula escritorio, cursor y ventanas con elementos HTML.
import { invoke } from '@tauri-apps/api/core';
import { listen } from '@tauri-apps/api/event';
import { getCurrentWebview } from '@tauri-apps/api/webview';

export const isTauri = typeof window !== 'undefined' && !!window.__TAURI_INTERNALS__;

const DEFAULTS = { visible: true, paused: false, autonomy: true, frequency: 'normal', volume: 50, size: 'mediano', perch: true, real_windows: false, autostart: false };

class TauriPlatform {
  constructor() { this.scr = null; this._ct = null; }
  async init() { this.scr = await invoke('screen_info'); return this.screen(); }
  screen() {
    const s = this.scr, k = s.scale;
    return {
      w: window.innerWidth, h: window.innerHeight, scale: k,
      work: { left: (s.work[0] - s.x) / k, top: (s.work[1] - s.y) / k, right: (s.work[2] - s.x) / k, bottom: (s.work[3] - s.y) / k },
    };
  }
  async refreshScreen() { this.scr = await invoke('screen_info'); return this.screen(); }
  async cursor() {
    const [x, y] = await invoke('cursor_pos'); const s = this.scr;
    return { x: (x - s.x) / s.scale, y: (y - s.y) / s.scale };
  }
  clickThrough(ignore) { if (this._ct === ignore) return; this._ct = ignore; invoke('set_click_through', { ignore }); }
  async windows() {
    const s = this.scr, k = s.scale;
    const list = await invoke('list_windows');
    return list.map((w) => ({ ...w, x: (w.x - s.x) / k, y: (w.y - s.y) / k, w: w.w / k, h: w.h / k }));
  }
  async moveWindow(hwnd, dx, dy) { return invoke('move_window', { hwnd, dx: Math.round(dx * this.scr.scale), dy: Math.round(dy * this.scr.scale) }); }
  async fullscreen() { return invoke('foreground_fullscreen'); }
  async settings() { return invoke('get_settings'); }
  setSetting(key, value) { return invoke('set_setting', { key, value }); }
  on(evt, cb) { return listen(evt, (e) => cb(e.payload)); }
  async onDrop(cb) {
    return getCurrentWebview().onDragDropEvent((e) => {
      const p = e.payload;
      if (p.type === 'drop') {
        const k = this.scr.scale;
        cb({ paths: p.paths, x: p.position.x / k, y: p.position.y / k });
      }
    });
  }
  quit() { invoke('quit'); }
}

// ---------- simulación para navegador ----------
class BrowserPlatform {
  constructor() {
    this.cur = { x: -999, y: -999 }; this.handlers = {}; this.set = { ...DEFAULTS };
    window.addEventListener('pointermove', (e) => { this.cur = { x: e.clientX, y: e.clientY }; });
  }
  async init() { return this.screen(); }
  screen() {
    const tb = document.getElementById('taskbar');
    const bottom = tb ? tb.getBoundingClientRect().top : window.innerHeight;
    return { w: window.innerWidth, h: window.innerHeight, scale: 1, work: { left: 0, top: 0, right: window.innerWidth, bottom } };
  }
  async refreshScreen() { return this.screen(); }
  async cursor() { return this.cur; }
  clickThrough(ignore) {
    const c = document.querySelector('canvas'); if (c) c.style.pointerEvents = ignore ? 'none' : 'auto';
  }
  async windows() {
    return [...document.querySelectorAll('.fakewin')].map((el, i) => {
      const r = el.getBoundingClientRect();
      return { hwnd: i + 1, x: r.left, y: r.top, w: r.width, h: r.height, title: el.dataset.title || 'Ventana', maximized: false };
    }).reverse();
  }
  async moveWindow(hwnd, dx, dy) {
    if (!this.set.real_windows) return false;
    const els = [...document.querySelectorAll('.fakewin')]; const el = els[hwnd - 1]; if (!el) return false;
    const x = el.offsetLeft + Math.max(-40, Math.min(40, dx)), y = el.offsetTop + dy;
    el.style.left = Math.max(-el.offsetWidth / 2, Math.min(window.innerWidth - el.offsetWidth / 2, x)) + 'px';
    el.style.top = y + 'px';
    return true;
  }
  async fullscreen() { return false; }
  async settings() { return this.set; }
  setSetting(key, value) { this.set[key] = value; this.emit('settings', this.set); }
  update(patch) { Object.assign(this.set, patch); this.emit('settings', { ...this.set }); }
  emit(evt, payload) { (this.handlers[evt] || []).forEach((f) => f(payload)); }
  on(evt, cb) { (this.handlers[evt] = this.handlers[evt] || []).push(cb); return Promise.resolve(() => {}); }
  async onDrop(cb) {
    window.addEventListener('dragover', (e) => e.preventDefault());
    window.addEventListener('drop', (e) => { e.preventDefault(); const f = [...(e.dataTransfer?.files || [])].map((x) => x.name); if (f.length) cb({ paths: f, x: e.clientX, y: e.clientY }); });
  }
  quit() {}
}

export function createPlatform() { return isTauri ? new TauriPlatform() : new BrowserPlatform(); }
