import { Game } from './game.js';
import { buildUI } from './ui.js';
const game = new Game({ assets: 'assets/' });
window.__game = game;
game.start().then(() => buildUI(game)).catch((e) => console.error(e));
