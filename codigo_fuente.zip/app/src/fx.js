// Efectos y objetos del mundo: partículas, sombra, orbe de juguete, documentos simulados, bocadillo.
import { Container, Graphics, Sprite, Text, Texture } from 'pixi.js';
import { radialTexture } from './dragonview.js';

const rand = (a, b) => a + Math.random() * (b - a);

export class Particles {
  constructor(layer) {
    this.layer = layer; this.list = []; this.pool = [];
    this.tex = {
      fire: radialTexture(64, [[0, 'rgba(255,255,220,1)'], [0.25, 'rgba(255,200,80,0.95)'], [0.6, 'rgba(255,90,10,0.5)'], [1, 'rgba(200,30,0,0)']]),
      smoke: radialTexture(64, [[0, 'rgba(90,80,75,0.55)'], [0.6, 'rgba(70,60,55,0.25)'], [1, 'rgba(60,50,45,0)']]),
      spark: radialTexture(32, [[0, 'rgba(255,240,180,1)'], [0.4, 'rgba(255,160,40,0.8)'], [1, 'rgba(255,100,0,0)']]),
      dust: radialTexture(64, [[0, 'rgba(200,180,150,0.5)'], [1, 'rgba(200,180,150,0)']]),
      glow: radialTexture(64, [[0, 'rgba(255,230,160,0.9)'], [1, 'rgba(255,200,120,0)']]),
    };
  }
  get active() { return this.list.length > 0; }
  spawn(kind, x, y, vx, vy, life, s0, s1, opts = {}) {
    let p = this.pool.pop();
    if (!p) { p = { sp: new Sprite(), txt: null }; p.sp.anchor.set(0.5); }
    if (p.txt) { p.txt.destroy(); p.txt = null; }
    p.sp.texture = this.tex[kind] || this.tex.glow;
    p.sp.blendMode = kind === 'fire' || kind === 'spark' ? 'add' : 'normal';
    p.sp.visible = true; p.sp.alpha = opts.alpha ?? 1; p.sp.rotation = rand(0, 6.28);
    p.sp.tint = opts.tint ?? 0xffffff;
    Object.assign(p, { kind, x, y, vx, vy, life, t: 0, s0, s1, g: opts.g ?? 0, drag: opts.drag ?? 0.98, spin: opts.spin ?? 0, a0: opts.alpha ?? 1 });
    this.layer.addChild(p.sp); this.list.push(p);
    return p;
  }
  text(str, x, y, opts = {}) {
    const p = this.spawn('glow', x, y, opts.vx ?? 10, opts.vy ?? -30, opts.life ?? 2.5, 1, 1.5, { alpha: 1, drag: 1, spin: 0 });
    p.sp.texture = Texture.EMPTY;
    p.txt = new Text({ text: str, style: { fill: opts.color ?? 0xf3e6d0, fontSize: opts.size ?? 22, fontFamily: 'Georgia, serif', fontStyle: 'italic', stroke: { color: 0x2a1a10, width: 3 } } });
    p.txt.anchor.set(0.5); p.sp.addChild(p.txt); p.sp.rotation = 0; p.wobble = true;
    return p;
  }
  update(dt) {
    for (let i = this.list.length - 1; i >= 0; i--) {
      const p = this.list[i]; p.t += dt;
      const k = p.t / p.life;
      if (k >= 1) { p.sp.visible = false; this.layer.removeChild(p.sp); this.list.splice(i, 1); this.pool.push(p); continue; }
      p.vx *= Math.pow(p.drag, dt * 60); p.vy = p.vy * Math.pow(p.drag, dt * 60) + p.g * dt;
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.sp.position.set(p.x + (p.wobble ? Math.sin(p.t * 3) * 6 : 0), p.y);
      const s = p.s0 + (p.s1 - p.s0) * k; p.sp.scale.set(s);
      p.sp.rotation += p.spin * dt;
      if (p.kind === 'fire') {
        p.sp.alpha = p.a0 * (1 - k) * (k < 0.1 ? k * 10 : 1);
        const c = k < 0.25 ? 0xffffff : k < 0.5 ? 0xffc070 : 0xff7030; p.sp.tint = c;
      } else p.sp.alpha = p.a0 * (1 - k) * Math.min(1, p.t * 6);
    }
  }
  clear() { for (const p of this.list) { p.sp.visible = false; this.layer.removeChild(p.sp); this.pool.push(p); } this.list = []; }
}

export class Shadow {
  constructor(layer) {
    this.g = new Graphics();
    for (let i = 0; i < 6; i++) this.g.ellipse(0, 0, 150 - i * 18, 18 - i * 2).fill({ color: 0x000000, alpha: 0.06 });
    layer.addChild(this.g);
  }
  set(x, y, scale, alpha) { this.g.position.set(x, y); this.g.scale.set(scale, scale); this.g.alpha = alpha; }
}

// Orbe brillante de juguete (como en la ficha)
export class Orb {
  constructor(layer) {
    this.c = new Container();
    const glow = new Sprite(radialTexture(128, [[0, 'rgba(200,170,255,0.6)'], [0.4, 'rgba(150,110,255,0.25)'], [1, 'rgba(120,80,255,0)']]));
    glow.anchor.set(0.5); glow.scale.set(0.9); glow.blendMode = 'add';
    const g = new Graphics();
    g.circle(0, 0, 15).fill(0x2a1d4a);
    g.circle(0, 0, 14).fill(0x6d55b8);
    g.circle(-3, -3, 9).fill({ color: 0xa996f0, alpha: 0.8 });
    g.circle(-5, -6, 3.5).fill({ color: 0xffffff, alpha: 0.9 });
    g.circle(0, 0, 15).stroke({ width: 1.5, color: 0xd9ccff, alpha: 0.6 });
    this.c.addChild(glow, g); this.glow = glow;
    layer.addChild(this.c);
    this.x = 0; this.y = 0; this.vx = 0; this.vy = 0; this.r = 15; this.alive = false; this.c.visible = false; this.t = 0;
  }
  spawn(x, y, vx = 0, vy = 0) { Object.assign(this, { x, y, vx, vy, alive: true, t: 0 }); this.c.visible = true; this.c.alpha = 1; }
  kill() { this.alive = false; this.c.visible = false; }
  update(dt, floorY, W, scale) {
    if (!this.alive) return;
    this.t += dt;
    this.vy += 900 * dt;
    this.x += this.vx * dt; this.y += this.vy * dt;
    const r = this.r * scale / 0.42;
    if (this.y > floorY - r) { this.y = floorY - r; this.vy = -Math.abs(this.vy) * 0.55; if (Math.abs(this.vy) < 40) this.vy = 0; this.vx *= 0.985; }
    if (this.x < r) { this.x = r; this.vx = Math.abs(this.vx) * 0.7; }
    if (this.x > W - r) { this.x = W - r; this.vx = -Math.abs(this.vx) * 0.7; }
    this.c.position.set(this.x, this.y); this.c.scale.set(scale / 0.42);
    this.c.rotation += this.vx * dt / r;
    this.glow.alpha = 0.7 + 0.3 * Math.sin(this.t * 4);
  }
}

// Documento simulado (folio) con física
export class Paper {
  constructor(layer, label = '') {
    this.c = new Container();
    const g = new Graphics();
    g.roundRect(-20, -26, 40, 52, 2).fill({ color: 0x000000, alpha: 0.12 });
    g.poly([-18, -25, 10, -25, 18, -17, 18, 25, -18, 25]).fill(0xfbf8f1).stroke({ width: 1, color: 0x9a8f80 });
    g.poly([10, -25, 10, -17, 18, -17]).fill(0xe2dccf).stroke({ width: 0.8, color: 0x9a8f80 });
    for (let i = 0; i < 7; i++) g.moveTo(-13, -15 + i * 5.5).lineTo(i === 6 ? 2 : 13, -15 + i * 5.5).stroke({ width: 1.2, color: 0x8b98a8, alpha: 0.7 });
    this.c.addChild(g);
    if (label) {
      const t = new Text({ text: label.length > 14 ? label.slice(0, 13) + '…' : label, style: { fontSize: 7, fill: 0x3a2a1a, fontFamily: 'Segoe UI, sans-serif' } });
      t.anchor.set(0.5); t.position.set(0, -20); this.c.addChild(t);
    }
    layer.addChild(this.c);
    Object.assign(this, { x: 0, y: 0, vx: 0, vy: 0, rot: 0, vr: 0, held: false, alive: true, flutter: false, onFloor: false, label, t: 0 });
  }
  get h() { return 26; }
  update(dt, floorY, W, scale) {
    if (!this.alive) return;
    this.t += dt;
    const s = scale / 0.42 * 0.9;
    if (!this.held) {
      if (this.flutter) { // cae como una hoja
        this.vy = Math.min(this.vy + 300 * dt, 170); this.vx = Math.sin(this.t * 2.2) * 80; this.rot = Math.sin(this.t * 2.2 + 1) * 0.6;
      } else { this.vy += 1100 * dt; this.rot += this.vr * dt; }
      this.x += this.vx * dt; this.y += this.vy * dt;
      const bottom = floorY - this.h * s * 0.92;
      if (this.y >= bottom) {
        this.y = bottom; this.flutter = false;
        if (this.vy > 200) { this.vy = -this.vy * 0.25; this.vr *= 0.5; } else { this.vy = 0; }
        this.vx *= Math.pow(0.02, dt); this.vr *= Math.pow(0.02, dt);
        const tgt = Math.round(this.rot / (Math.PI * 2)) * Math.PI * 2 + (this.rot % (Math.PI * 2) > 0 ? 0.1 : -0.1);
        this.rot += (tgt - this.rot) * Math.min(1, dt * 6);
        this.onFloor = Math.abs(this.vx) < 15;
      } else this.onFloor = false;
      if (this.x < 20) { this.x = 20; this.vx = Math.abs(this.vx) * 0.5; }
      if (this.x > W - 20) { this.x = W - 20; this.vx = -Math.abs(this.vx) * 0.5; }
    }
    this.c.position.set(this.x, this.y); this.c.rotation = this.rot; this.c.scale.set(s);
  }
  destroy() { this.alive = false; this.c.destroy({ children: true }); }
}

export class Bubble {
  constructor(layer) {
    this.c = new Container(); this.g = new Graphics();
    this.t = new Text({ text: '', style: { fontSize: 14, fill: 0x2a1a10, fontFamily: 'Georgia, serif', wordWrap: true, wordWrapWidth: 220 } });
    this.c.addChild(this.g, this.t); this.c.visible = false; layer.addChild(this.c); this.life = 0;
  }
  show(text, secs = 3) {
    this.t.text = text; const w = Math.min(240, this.t.width + 22), h = this.t.height + 14;
    this.g.clear().roundRect(-w / 2, -h, w, h, 10).fill({ color: 0xf6efe2, alpha: 0.95 }).stroke({ width: 1.5, color: 0x6b4a30 })
      .poly([-8, 0, 8, 0, 0, 12]).fill({ color: 0xf6efe2, alpha: 0.95 });
    this.t.position.set(-w / 2 + 11, -h + 7);
    this.c.visible = true; this.life = secs;
  }
  update(dt, x, y) { if (!this.c.visible) return; this.life -= dt; this.c.position.set(x, y); this.c.alpha = Math.min(1, this.life * 3); if (this.life <= 0) this.c.visible = false; }
}
