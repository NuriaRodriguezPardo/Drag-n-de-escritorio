import { Game } from './game.js';
import { buildUI } from './ui.js';

// Escritorio simulado: ventanas arrastrables
function makeDraggable(win) {
  const bar = win.querySelector('.bar'); let st = null;
  bar.addEventListener('pointerdown', (e) => { st = { x: e.clientX - win.offsetLeft, y: e.clientY - win.offsetTop }; bar.setPointerCapture(e.pointerId); });
  bar.addEventListener('pointermove', (e) => { if (st) { win.style.left = e.clientX - st.x + 'px'; win.style.top = e.clientY - st.y + 'px'; } });
  bar.addEventListener('pointerup', () => { st = null; });
}
document.querySelectorAll('.fakewin').forEach(makeDraggable);

const game = new Game({ assets: 'assets/', enterDelay: 600 });
window.__game = game;
game.start().then(() => {
  buildUI(game);
  const P = game.P;
  const $ = (id) => document.getElementById(id);
  document.querySelectorAll('[data-cmd]').forEach((b) => b.onclick = () => { game.sound.ensure(); if (!game.d.present) game.summon(); game.command(b.dataset.cmd); });
  document.querySelectorAll('[data-mood]').forEach((b) => b.onclick = () => { game.setMood(b.dataset.mood); });
  $('autonomy').onchange = (e) => P.update({ autonomy: e.target.checked });
  $('real').onchange = (e) => P.update({ real_windows: e.target.checked });
  $('perch').onchange = (e) => P.update({ perch: e.target.checked });
  $('size').onchange = (e) => P.update({ size: e.target.value });
  $('vol').oninput = (e) => { game.sound.ensure(); P.update({ volume: Number(e.target.value) }); };
  $('pause').onclick = () => { P.update({ paused: !game.settings.paused }); $('pause').textContent = game.settings.paused ? '▶ Reanudar' : '⏸ Pausar'; };
  $('toggle').onclick = () => document.getElementById('panel').classList.toggle('min');
  game.onMood = (m) => { $('mood').textContent = m; };
  setInterval(() => { $('state').textContent = (game.genName || '—'); }, 300);
  P.update({ frequency: 'siempre' });
});
