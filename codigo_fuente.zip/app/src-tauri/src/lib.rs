// Backend nativo del Dragón de Escritorio.
// - Ventana superpuesta transparente, sin bordes, siempre encima y "atravesable" por el ratón.
// - Icono en la bandeja con el menú de control.
// - Consulta de cursor, área de trabajo y ventanas visibles (sólo lectura).
// - Mover ventanas reales SOLO si el usuario lo activó y lo confirmó (nunca cierra, borra ni modifica archivos).

use serde::{Deserialize, Serialize};
use std::sync::Mutex;
use tauri::{
    menu::{CheckMenuItem, Menu, MenuItem, PredefinedMenuItem, Submenu},
    tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent},
    AppHandle, Emitter, Manager, PhysicalPosition, PhysicalSize, Wry,
};

#[derive(Clone, Serialize, Deserialize)]
#[serde(default)]
pub struct Settings {
    pub visible: bool,
    pub paused: bool,
    pub autonomy: bool,
    pub frequency: String, // "baja" | "normal" | "alta" | "siempre"
    pub volume: u32,       // 0..100
    pub size: String,      // "pequeno" | "mediano" | "grande"
    pub perch: bool,       // posarse sobre ventanas (sólo lectura)
    pub real_windows: bool, // empujar ventanas reales (requiere confirmación)
    pub autostart: bool,
}
impl Default for Settings {
    fn default() -> Self {
        Settings {
            visible: true, paused: false, autonomy: true, frequency: "normal".into(), volume: 50,
            size: "mediano".into(), perch: true, real_windows: false, autostart: false,
        }
    }
}

struct AppState {
    settings: Mutex<Settings>,
    items: Mutex<Option<MenuItems>>,
}

struct MenuItems {
    visible: CheckMenuItem<Wry>,
    paused: CheckMenuItem<Wry>,
    autonomy: CheckMenuItem<Wry>,
    perch: CheckMenuItem<Wry>,
    real: CheckMenuItem<Wry>,
    autostart: CheckMenuItem<Wry>,
    freq: Vec<(String, CheckMenuItem<Wry>)>,
    vol: Vec<(u32, CheckMenuItem<Wry>)>,
    size: Vec<(String, CheckMenuItem<Wry>)>,
}

fn settings_path(app: &AppHandle) -> Option<std::path::PathBuf> {
    app.path().app_config_dir().ok().map(|d| d.join("ajustes.json"))
}
fn load_settings(app: &AppHandle) -> Settings {
    settings_path(app)
        .and_then(|p| std::fs::read_to_string(p).ok())
        .and_then(|s| serde_json::from_str(&s).ok())
        .unwrap_or_default()
}
fn save_settings(app: &AppHandle, s: &Settings) {
    if let Some(p) = settings_path(app) {
        if let Some(dir) = p.parent() { let _ = std::fs::create_dir_all(dir); }
        let _ = std::fs::write(p, serde_json::to_string_pretty(s).unwrap_or_default());
    }
}

fn sync_menu(app: &AppHandle) {
    let st = app.state::<AppState>();
    let s = st.settings.lock().unwrap().clone();
    let guard = st.items.lock().unwrap();
    if let Some(m) = guard.as_ref() {
        let _ = m.visible.set_checked(s.visible);
        let _ = m.paused.set_checked(s.paused);
        let _ = m.autonomy.set_checked(s.autonomy);
        let _ = m.perch.set_checked(s.perch);
        let _ = m.real.set_checked(s.real_windows);
        let _ = m.autostart.set_checked(s.autostart);
        for (k, it) in &m.freq { let _ = it.set_checked(*k == s.frequency); }
        for (k, it) in &m.vol { let _ = it.set_checked(*k == s.volume); }
        for (k, it) in &m.size { let _ = it.set_checked(*k == s.size); }
    }
    drop(guard);
}

fn apply_settings(app: &AppHandle) {
    let s = app.state::<AppState>().settings.lock().unwrap().clone();
    save_settings(app, &s);
    sync_menu(app);
    if let Some(w) = app.get_webview_window("main") {
        if s.visible { let _ = w.show(); platform::style_overlay(&w); } else { let _ = w.hide(); }
    }
    let _ = app.emit("settings", s);
}

fn update<F: FnOnce(&mut Settings)>(app: &AppHandle, f: F) {
    {
        let st = app.state::<AppState>();
        let mut s = st.settings.lock().unwrap();
        f(&mut s);
    }
    apply_settings(app);
}

// ---------------- comandos ----------------
#[derive(Serialize)]
struct ScreenInfo { x: i32, y: i32, w: u32, h: u32, scale: f64, work: [i32; 4] }

#[tauri::command]
fn get_settings(state: tauri::State<AppState>) -> Settings { state.settings.lock().unwrap().clone() }

#[tauri::command]
fn set_setting(app: AppHandle, key: String, value: serde_json::Value) {
    update(&app, |s| {
        match key.as_str() {
            "visible" => s.visible = value.as_bool().unwrap_or(s.visible),
            "paused" => s.paused = value.as_bool().unwrap_or(s.paused),
            "autonomy" => s.autonomy = value.as_bool().unwrap_or(s.autonomy),
            _ => {}
        }
    });
}

#[tauri::command]
fn screen_info(window: tauri::WebviewWindow) -> ScreenInfo {
    let mon = window.primary_monitor().ok().flatten();
    let (x, y, w, h, scale) = match &mon {
        Some(m) => (m.position().x, m.position().y, m.size().width, m.size().height, m.scale_factor()),
        None => (0, 0, 1920, 1080, 1.0),
    };
    let work = platform::work_area().unwrap_or([x, y, x + w as i32, y + h as i32 - 48]);
    ScreenInfo { x, y, w, h, scale, work }
}

#[tauri::command]
fn cursor_pos() -> (i32, i32) { platform::cursor_pos() }

#[tauri::command]
fn set_click_through(window: tauri::WebviewWindow, ignore: bool) {
    let _ = window.set_ignore_cursor_events(ignore);
}

#[tauri::command]
fn list_windows(window: tauri::WebviewWindow) -> Vec<platform::WinInfo> {
    let own = platform::hwnd_of(&window);
    platform::list_windows(own)
}

#[tauri::command]
fn move_window(state: tauri::State<AppState>, window: tauri::WebviewWindow, hwnd: isize, dx: i32, dy: i32) -> bool {
    if !state.settings.lock().unwrap().real_windows { return false; }
    let own = platform::hwnd_of(&window);
    if hwnd == own { return false; }
    platform::move_window(hwnd, dx, dy)
}

#[tauri::command]
fn foreground_fullscreen(window: tauri::WebviewWindow) -> bool {
    platform::foreground_fullscreen(platform::hwnd_of(&window))
}

#[tauri::command]
fn confirm(title: String, message: String) -> bool { platform::confirm(&title, &message) }

#[tauri::command]
fn quit(app: AppHandle) { app.exit(0); }

// ---------------- arranque ----------------
pub fn run() {
    tauri::Builder::default()
        .plugin(tauri_plugin_single_instance::init(|app, _args, _cwd| {
            update(app, |s| { s.visible = true; s.paused = false; });
            let _ = app.emit("summon", ());
        }))
        .manage(AppState { settings: Mutex::new(Settings::default()), items: Mutex::new(None) })
        .invoke_handler(tauri::generate_handler![
            get_settings, set_setting, screen_info, cursor_pos, set_click_through, list_windows,
            move_window, foreground_fullscreen, confirm, quit
        ])
        .setup(|app| {
            let handle = app.handle().clone();
            let s = load_settings(&handle);
            *app.state::<AppState>().settings.lock().unwrap() = s.clone();

            // ventana superpuesta a pantalla completa del monitor principal
            let win = app.get_webview_window("main").unwrap();
            if let Ok(Some(m)) = win.primary_monitor() {
                let _ = win.set_position(PhysicalPosition::new(m.position().x, m.position().y));
                let _ = win.set_size(PhysicalSize::new(m.size().width, m.size().height));
            }
            let _ = win.set_ignore_cursor_events(true);
            platform::style_overlay(&win);
            if s.visible { let _ = win.show(); platform::style_overlay(&win); }

            // menú de la bandeja
            let visible = CheckMenuItem::with_id(app, "visible", "Mostrar dragón", true, s.visible, None::<&str>)?;
            let summon = MenuItem::with_id(app, "summon", "Llamar al dragón ahora", true, None::<&str>)?;
            let paused = CheckMenuItem::with_id(app, "paused", "Pausar animaciones", true, s.paused, None::<&str>)?;
            let autonomy = CheckMenuItem::with_id(app, "autonomy", "Autonomía (vida propia)", true, s.autonomy, None::<&str>)?;
            let freq_defs = [("baja", "Baja"), ("normal", "Normal"), ("alta", "Alta"), ("siempre", "Siempre presente")];
            let mut freq = vec![];
            for (k, l) in freq_defs { freq.push((k.to_string(), CheckMenuItem::with_id(app, format!("freq_{k}"), l, true, s.frequency == k, None::<&str>)?)); }
            let vol_defs = [0u32, 25, 50, 75, 100];
            let mut vol = vec![];
            for v in vol_defs {
                let label = if v == 0 { "Silencio".to_string() } else { format!("{v} %") };
                vol.push((v, CheckMenuItem::with_id(app, format!("vol_{v}"), label, true, s.volume == v, None::<&str>)?));
            }
            let size_defs = [("pequeno", "Pequeño"), ("mediano", "Mediano"), ("grande", "Grande")];
            let mut size = vec![];
            for (k, l) in size_defs { size.push((k.to_string(), CheckMenuItem::with_id(app, format!("size_{k}"), l, true, s.size == k, None::<&str>)?)); }
            let perch = CheckMenuItem::with_id(app, "perch", "Posarse sobre ventanas", true, s.perch, None::<&str>)?;
            let real = CheckMenuItem::with_id(app, "real", "Permitir empujar ventanas reales…", true, s.real_windows, None::<&str>)?;
            let autostart = CheckMenuItem::with_id(app, "autostart", "Iniciar con Windows", true, s.autostart, None::<&str>)?;
            let help = MenuItem::with_id(app, "help", "Instrucciones", true, None::<&str>)?;
            let quit_i = MenuItem::with_id(app, "quit", "Cerrar la aplicación", true, None::<&str>)?;

            let freq_refs: Vec<&dyn tauri::menu::IsMenuItem<Wry>> = freq.iter().map(|(_, i)| i as &dyn tauri::menu::IsMenuItem<Wry>).collect();
            let freq_menu = Submenu::with_items(app, "Frecuencia de aparición", true, &freq_refs)?;
            let vol_refs: Vec<&dyn tauri::menu::IsMenuItem<Wry>> = vol.iter().map(|(_, i)| i as &dyn tauri::menu::IsMenuItem<Wry>).collect();
            let vol_menu = Submenu::with_items(app, "Volumen", true, &vol_refs)?;
            let size_refs: Vec<&dyn tauri::menu::IsMenuItem<Wry>> = size.iter().map(|(_, i)| i as &dyn tauri::menu::IsMenuItem<Wry>).collect();
            let size_menu = Submenu::with_items(app, "Tamaño", true, &size_refs)?;
            let interact = Submenu::with_items(app, "Interacción con Windows", true, &[&perch, &real])?;
            let sep1 = PredefinedMenuItem::separator(app)?;
            let sep2 = PredefinedMenuItem::separator(app)?;
            let sep3 = PredefinedMenuItem::separator(app)?;
            let menu = Menu::with_items(app, &[
                &visible, &summon, &sep1, &paused, &autonomy, &freq_menu, &vol_menu, &size_menu, &interact,
                &sep2, &autostart, &help, &sep3, &quit_i,
            ])?;
            *app.state::<AppState>().items.lock().unwrap() = Some(MenuItems {
                visible: visible.clone(), paused: paused.clone(), autonomy: autonomy.clone(), perch: perch.clone(),
                real: real.clone(), autostart: autostart.clone(), freq, vol, size,
            });

            TrayIconBuilder::with_id("tray")
                .icon(app.default_window_icon().unwrap().clone())
                .tooltip("Dragón de Escritorio")
                .menu(&menu)
                .show_menu_on_left_click(false)
                .on_tray_icon_event(|tray, event| {
                    if let TrayIconEvent::Click { button: MouseButton::Left, button_state: MouseButtonState::Up, .. } = event {
                        let app = tray.app_handle();
                        update(app, |s| s.visible = !s.visible);
                    }
                })
                .on_menu_event(|app, event| {
                    let id = event.id().as_ref().to_string();
                    match id.as_str() {
                        "visible" => update(app, |s| s.visible = !s.visible),
                        "summon" => { update(app, |s| { s.visible = true; s.paused = false; }); let _ = app.emit("summon", ()); }
                        "paused" => update(app, |s| s.paused = !s.paused),
                        "autonomy" => update(app, |s| s.autonomy = !s.autonomy),
                        "perch" => update(app, |s| s.perch = !s.perch),
                        "real" => {
                            let cur = app.state::<AppState>().settings.lock().unwrap().real_windows;
                            let ok = cur || platform::confirm("Dragón de Escritorio",
                                "¿Permitir que el dragón empuje (mueva) ventanas reales?\n\nSólo las desplazará unos centímetros dentro de la pantalla. Nunca cerrará ventanas ni tocará tus archivos.\n\nPuedes desactivarlo cuando quieras desde este menú.");
                            update(app, |s| s.real_windows = if cur { false } else { ok });
                        }
                        "autostart" => {
                            let want = !app.state::<AppState>().settings.lock().unwrap().autostart;
                            let ok = platform::set_autostart(want);
                            update(app, |s| if ok { s.autostart = want });
                        }
                        "help" => { let _ = app.emit("help", ()); }
                        "quit" => app.exit(0),
                        x if x.starts_with("freq_") => { let v = x[5..].to_string(); update(app, |s| s.frequency = v); }
                        x if x.starts_with("vol_") => { let v: u32 = x[4..].parse().unwrap_or(50); update(app, |s| s.volume = v); }
                        x if x.starts_with("size_") => { let v = x[5..].to_string(); update(app, |s| s.size = v); }
                        _ => {}
                    }
                })
                .build(app)?;
            Ok(())
        })
        .run(tauri::generate_context!())
        .expect("error al iniciar el Dragón de Escritorio");
}

// ---------------- capa específica de Windows ----------------
#[cfg(windows)]
mod platform {
    use serde::Serialize;
    use windows::core::{BOOL, PCWSTR};
    use windows::Win32::Foundation::{HWND, LPARAM, POINT, RECT};
    use windows::Win32::Graphics::Dwm::{DwmGetWindowAttribute, DWMWA_CLOAKED, DWMWA_EXTENDED_FRAME_BOUNDS};
    use windows::Win32::Graphics::Gdi::{GetMonitorInfoW, MonitorFromWindow, MONITORINFO, MONITOR_DEFAULTTONEAREST};
    use windows::Win32::UI::WindowsAndMessaging::*;

    #[derive(Serialize, Clone)]
    pub struct WinInfo { pub hwnd: isize, pub x: i32, pub y: i32, pub w: i32, pub h: i32, pub title: String, pub maximized: bool }

    pub fn hwnd_of(w: &tauri::WebviewWindow) -> isize { w.hwnd().map(|h| h.0 as isize).unwrap_or(0) }

    pub fn style_overlay(w: &tauri::WebviewWindow) {
        if let Ok(h) = w.hwnd() {
            unsafe {
                let hwnd = HWND(h.0);
                let ex = GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
                let add = (WS_EX_TOOLWINDOW.0 | WS_EX_NOACTIVATE.0) as isize;
                let ex = (ex | add) & !(WS_EX_APPWINDOW.0 as isize);
                SetWindowLongPtrW(hwnd, GWL_EXSTYLE, ex);
            }
        }
    }

    pub fn cursor_pos() -> (i32, i32) {
        let mut p = POINT::default();
        unsafe { let _ = GetCursorPos(&mut p); }
        (p.x, p.y)
    }

    pub fn work_area() -> Option<[i32; 4]> {
        let mut r = RECT::default();
        unsafe {
            SystemParametersInfoW(SPI_GETWORKAREA, 0, Some(&mut r as *mut _ as *mut _), SYSTEM_PARAMETERS_INFO_UPDATE_FLAGS(0)).ok()?;
        }
        Some([r.left, r.top, r.right, r.bottom])
    }

    fn title_of(h: HWND) -> String {
        let mut buf = [0u16; 256];
        let n = unsafe { GetWindowTextW(h, &mut buf) };
        String::from_utf16_lossy(&buf[..n.max(0) as usize])
    }

    fn frame_rect(h: HWND) -> RECT {
        let mut r = RECT::default();
        unsafe {
            if DwmGetWindowAttribute(h, DWMWA_EXTENDED_FRAME_BOUNDS, &mut r as *mut _ as *mut _, std::mem::size_of::<RECT>() as u32).is_err() {
                let _ = GetWindowRect(h, &mut r);
            }
        }
        r
    }

    struct Ctx { own: isize, out: Vec<WinInfo> }

    unsafe extern "system" fn enum_cb(h: HWND, lp: LPARAM) -> BOOL {
        let ctx = &mut *(lp.0 as *mut Ctx);
        if h.0 as isize == ctx.own { return BOOL(1); }
        if !IsWindowVisible(h).as_bool() || IsIconic(h).as_bool() { return BOOL(1); }
        let ex = GetWindowLongPtrW(h, GWL_EXSTYLE) as u32;
        if ex & WS_EX_TOOLWINDOW.0 != 0 { return BOOL(1); }
        let mut cloaked: u32 = 0;
        let _ = DwmGetWindowAttribute(h, DWMWA_CLOAKED, &mut cloaked as *mut _ as *mut _, 4);
        if cloaked != 0 { return BOOL(1); }
        let title = title_of(h);
        if title.is_empty() || title == "Program Manager" { return BOOL(1); }
        let r = frame_rect(h);
        let (w, hh) = (r.right - r.left, r.bottom - r.top);
        if w < 160 || hh < 90 { return BOOL(1); }
        let style = GetWindowLongPtrW(h, GWL_STYLE) as u32;
        ctx.out.push(WinInfo { hwnd: h.0 as isize, x: r.left, y: r.top, w, h: hh, title, maximized: style & WS_MAXIMIZE.0 != 0 });
        BOOL(1)
    }

    pub fn list_windows(own: isize) -> Vec<WinInfo> {
        let mut ctx = Ctx { own, out: vec![] };
        unsafe { let _ = EnumWindows(Some(enum_cb), LPARAM(&mut ctx as *mut _ as isize)); }
        ctx.out.truncate(24);
        ctx.out
    }

    pub fn move_window(hwnd: isize, dx: i32, dy: i32) -> bool {
        unsafe {
            let h = HWND(hwnd as *mut _);
            if !IsWindow(Some(h)).as_bool() || !IsWindowVisible(h).as_bool() { return false; }
            let style = GetWindowLongPtrW(h, GWL_STYLE) as u32;
            if style & WS_MAXIMIZE.0 != 0 || IsIconic(h).as_bool() { return false; }
            let mut r = RECT::default();
            if GetWindowRect(h, &mut r).is_err() { return false; }
            let wa = work_area().unwrap_or([0, 0, 1920, 1040]);
            let w = r.right - r.left;
            let nx = (r.left + dx.clamp(-40, 40)).clamp(wa[0] - w / 2, wa[2] - w / 2);
            let ny = (r.top + dy.clamp(-40, 40)).clamp(wa[1], wa[3] - 40);
            SetWindowPos(h, None, nx, ny, 0, 0, SWP_NOSIZE | SWP_NOZORDER | SWP_NOACTIVATE).is_ok()
        }
    }

    pub fn foreground_fullscreen(own: isize) -> bool {
        unsafe {
            let h = GetForegroundWindow();
            if h.0.is_null() || h.0 as isize == own { return false; }
            let mut cls = [0u16; 64];
            let n = GetClassNameW(h, &mut cls);
            let c = String::from_utf16_lossy(&cls[..n.max(0) as usize]);
            if c == "Progman" || c == "WorkerW" || c == "Shell_TrayWnd" { return false; }
            let mut r = RECT::default();
            if GetWindowRect(h, &mut r).is_err() { return false; }
            let mon = MonitorFromWindow(h, MONITOR_DEFAULTTONEAREST);
            let mut mi = MONITORINFO { cbSize: std::mem::size_of::<MONITORINFO>() as u32, ..Default::default() };
            if !GetMonitorInfoW(mon, &mut mi).as_bool() { return false; }
            let m = mi.rcMonitor;
            r.left <= m.left && r.top <= m.top && r.right >= m.right && r.bottom >= m.bottom
        }
    }

    fn wide(s: &str) -> Vec<u16> { s.encode_utf16().chain(std::iter::once(0)).collect() }

    pub fn confirm(title: &str, msg: &str) -> bool {
        let t = wide(title); let m = wide(msg);
        unsafe {
            MessageBoxW(None, PCWSTR(m.as_ptr()), PCWSTR(t.as_ptr()), MB_YESNO | MB_ICONQUESTION | MB_TOPMOST | MB_SETFOREGROUND) == IDYES
        }
    }

    pub fn set_autostart(enable: bool) -> bool {
        use winreg::{enums::HKEY_CURRENT_USER, RegKey};
        let hk = RegKey::predef(HKEY_CURRENT_USER);
        let Ok((key, _)) = hk.create_subkey("Software\\Microsoft\\Windows\\CurrentVersion\\Run") else { return false };
        if enable {
            let Ok(exe) = std::env::current_exe() else { return false };
            key.set_value("DragonEscritorio", &format!("\"{}\"", exe.display())).is_ok()
        } else {
            let _ = key.delete_value("DragonEscritorio");
            true
        }
    }
}

// Implementación vacía para compilar/probar en otros sistemas.
#[cfg(not(windows))]
mod platform {
    use serde::Serialize;
    #[derive(Serialize, Clone)]
    pub struct WinInfo { pub hwnd: isize, pub x: i32, pub y: i32, pub w: i32, pub h: i32, pub title: String, pub maximized: bool }
    pub fn hwnd_of(_: &tauri::WebviewWindow) -> isize { 0 }
    pub fn style_overlay(_: &tauri::WebviewWindow) {}
    pub fn cursor_pos() -> (i32, i32) { (0, 0) }
    pub fn work_area() -> Option<[i32; 4]> { None }
    pub fn list_windows(_: isize) -> Vec<WinInfo> { vec![] }
    pub fn move_window(_: isize, _: i32, _: i32) -> bool { false }
    pub fn foreground_fullscreen(_: isize) -> bool { false }
    pub fn confirm(_: &str, _: &str) -> bool { true }
    pub fn set_autostart(_: bool) -> bool { false }
}
