import { build } from 'esbuild';
import { cpSync, mkdirSync, copyFileSync } from 'fs';
mkdirSync('dist/assets', { recursive: true });
await build({ entryPoints: ['src/index.js'], bundle: true, minify: true, format: 'esm', outfile: 'dist/main.js', target: 'chrome110', legalComments: 'none' });
copyFileSync('index.html', 'dist/index.html');
for (const f of ['rig.json', 'body.webp', 'wing.webp']) copyFileSync('public/assets/' + f, 'dist/assets/' + f);
console.log('frontend listo');
