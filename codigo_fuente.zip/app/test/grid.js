import { Application, Assets, Container, Text } from 'pixi.js';
import { DragonView } from '../src/dragonview.js';
const q = new URLSearchParams(location.search);
const acts = (q.get('acts') || 'stand,walk,run,sit,lie,sleep,fly,glide,hover,fire,push,kick').split(',');
const times = (q.get('times') || '0.5').split(',').map(Number);
(async () => {
  const cols = times.length > 1 ? times.length : Math.min(4, acts.length);
  const rows = times.length > 1 ? acts.length : Math.ceil(acts.length / cols);
  const sc0 = Number(q.get('sc')||0.42); const cw = Math.round(700*sc0), ch = Math.round(560*sc0);
  const app = new Application();
  await app.init({ width: cols * cw, height: rows * ch, background: '#3a4250', antialias: true, preference: 'webgl' });
  document.body.appendChild(app.canvas);
  const rig = await (await fetch('../public/assets/rig.json')).json();
  const tex = { body: await Assets.load('../public/assets/body.png'), wing: await Assets.load('../public/assets/wing.png') };
  let k = 0;
  for (let r = 0; r < acts.length; r++) for (let c = 0; c < (times.length > 1 ? times.length : 1); c++) {
    const act = acts[r], t = times.length > 1 ? times[c] : times[0];
    const dv = new DragonView(rig, tex);
    dv.setAct(act);
    const D = dv.D; D.mood = q.get('mood') || 'contento'; if (q.get('wf')) D.wingFold = Number(q.get('wf').split(',')[k % q.get('wf').split(',').length]);
    // simular t segundos a 60 fps
    const dt = 1 / 60; const n = Math.round(t / dt) + 60;
    for (let i = 0; i < n; i++) {
      D.gaitPhase = (D.t * (act === 'run' ? 1.6 : 0.9)) % 1;
      D.flapPhase = (D.t * 1.6) % 1;
      if (act === 'fire') D.actT = Math.max(0, D.t - 1);
      dv.update(dt);
    }
    const gx = (times.length > 1 ? c : k % cols) * cw, gy = (times.length > 1 ? r : Math.floor(k / cols)) * ch;
    dv.view.scale.set(Number(q.get('sc')||0.42));
    dv.view.position.set(gx + 50*sc0, gy + 90*sc0);
    app.stage.addChild(dv.view);
    const tl = new Text({ text: act + ' t=' + t, style: { fill: 0xffffff, fontSize: 13 } }); tl.position.set(gx + 4, gy + 4);
    app.stage.addChild(tl);
    k++;
  }
  app.render();
  document.title = 'READY';
})();
