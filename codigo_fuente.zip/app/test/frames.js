import { Application, Assets } from 'pixi.js';
import { DragonView } from '../src/dragonview.js';
window.renderFrames = async (act, n, dur, opts = {}) => {
  if (!window._app) {
    const app = new Application();
    await app.init({ width: 420, height: 340, backgroundAlpha: 0, antialias: true, preserveDrawingBuffer: true, preference: 'webgl' });
    document.body.appendChild(app.canvas);
    window._rig = await (await fetch('../public/assets/rig.json')).json();
    window._tex = { body: await Assets.load('../public/assets/body.webp'), wing: await Assets.load('../public/assets/wing.webp') };
    window._app = app;
  }
  const app = window._app; app.stage.removeChildren();
  const dv = new DragonView(window._rig, window._tex); dv.setAct(act); dv.D.mood = opts.mood || 'contento';
  if (opts.wf !== undefined) dv.D.wingFold = opts.wf;
  dv.view.scale.set(0.62); dv.view.position.set(24, opts.y ?? 30); app.stage.addChild(dv.view);
  const dt = 1 / 60; for (let i = 0; i < 90; i++) { step(dv, act, dt, opts); dv.update(dt); }
  const out = []; const per = Math.round(dur / n / dt);
  for (let f = 0; f < n; f++) { for (let i = 0; i < per; i++) { step(dv, act, dt, opts); dv.update(dt); } app.render(); out.push(app.canvas.toDataURL('image/png')); }
  return out;
};
function step(dv, act, dt, opts) {
  const D = dv.D;
  D.gaitPhase = (D.gaitPhase + dt * (act === 'run' ? 1.8 : 1.2)) % 1;
  D.flapPhase = (D.flapPhase + dt * 1.6) % 1;
  if (opts.loopAct) D.actT = D.actT % opts.loopAct;
}
document.title = 'READY';
