; Instalador del Dragón de Escritorio (NSIS, por usuario, sin permisos de administrador)
Unicode true
!include "MUI2.nsh"
!include "LogicLib.nsh"

!define APPNAME "Dragón de Escritorio"
!define EXENAME "DragonEscritorio.exe"
!define REGKEY "Software\Microsoft\Windows\CurrentVersion\Uninstall\DragonEscritorio"
!define VERSION "1.0.0"

Name "${APPNAME}"
OutFile "${OUTDIR}\DragonEscritorio-Instalador-${VERSION}.exe"
InstallDir "$LOCALAPPDATA\Programs\DragonEscritorio"
RequestExecutionLevel user
SetCompressor /SOLID lzma
BrandingText "Ember · ${APPNAME} ${VERSION}"

!define MUI_ICON "${SRCDIR}\icon.ico"
!define MUI_UNICON "${SRCDIR}\icon.ico"
!define MUI_WELCOMEFINISHPAGE_BITMAP "${SRCDIR}\welcome.bmp"
!define MUI_ABORTWARNING
!define MUI_WELCOMEPAGE_TITLE "Bienvenido a ${APPNAME}"
!define MUI_WELCOMEPAGE_TEXT "Este asistente instalará a Ember, un dragón adulto que vivirá en tu escritorio: caminará, volará, dormirá, jugará y se posará sobre tus ventanas.$\r$\n$\r$\nNo necesita permisos de administrador ni conexión a Internet."
!define MUI_FINISHPAGE_RUN "$INSTDIR\${EXENAME}"
!define MUI_FINISHPAGE_RUN_TEXT "Despertar al dragón ahora"
!define MUI_FINISHPAGE_SHOWREADME "$INSTDIR\LEEME.txt"
!define MUI_FINISHPAGE_SHOWREADME_TEXT "Ver instrucciones"
!define MUI_FINISHPAGE_SHOWREADME_NOTCHECKED

!insertmacro MUI_PAGE_WELCOME
!insertmacro MUI_PAGE_COMPONENTS
!insertmacro MUI_PAGE_DIRECTORY
!insertmacro MUI_PAGE_INSTFILES
!insertmacro MUI_PAGE_FINISH
!insertmacro MUI_UNPAGE_CONFIRM
!insertmacro MUI_UNPAGE_INSTFILES
!insertmacro MUI_LANGUAGE "Spanish"

Function .onInit
  ; ¿Está WebView2 instalado? (incluido en Windows 11 y en Windows 10 actualizado)
  ReadRegStr $0 HKLM "SOFTWARE\WOW6432Node\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" "pv"
  ${If} $0 == ""
    ReadRegStr $0 HKCU "Software\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" "pv"
  ${EndIf}
  ${If} $0 == ""
    ReadRegStr $0 HKLM "SOFTWARE\Microsoft\EdgeUpdate\Clients\{F3017226-FE2A-4295-8BDF-00C3A9A7E4C5}" "pv"
  ${EndIf}
  ${If} $0 == ""
  ${OrIf} $0 == "0.0.0.0"
    MessageBox MB_YESNO|MB_ICONINFORMATION "El dragón necesita Microsoft Edge WebView2 Runtime, que no parece estar instalado.$\r$\n$\r$\n¿Abrir la página oficial de descarga de Microsoft? (Después vuelve a ejecutar este instalador.)" IDNO +2
      ExecShell "open" "https://go.microsoft.com/fwlink/p/?LinkId=2124703"
  ${EndIf}
FunctionEnd

Section "Dragón de Escritorio (necesario)" SecMain
  SectionIn RO
  nsExec::Exec 'taskkill /IM ${EXENAME} /F'
  Sleep 400
  SetOutPath "$INSTDIR"
  File "${SRCDIR}\${EXENAME}"
  File "${SRCDIR}\WebView2Loader.dll"
  File "${SRCDIR}\LEEME.txt"
  File "${SRCDIR}\icon.ico"
  WriteUninstaller "$INSTDIR\Desinstalar.exe"
  CreateDirectory "$SMPROGRAMS\${APPNAME}"
  CreateShortcut "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk" "$INSTDIR\${EXENAME}" "" "$INSTDIR\icon.ico"
  CreateShortcut "$SMPROGRAMS\${APPNAME}\Desinstalar.lnk" "$INSTDIR\Desinstalar.exe"
  WriteRegStr HKCU "${REGKEY}" "DisplayName" "${APPNAME}"
  WriteRegStr HKCU "${REGKEY}" "DisplayVersion" "${VERSION}"
  WriteRegStr HKCU "${REGKEY}" "Publisher" "Ember"
  WriteRegStr HKCU "${REGKEY}" "DisplayIcon" "$INSTDIR\icon.ico"
  WriteRegStr HKCU "${REGKEY}" "UninstallString" '"$INSTDIR\Desinstalar.exe"'
  WriteRegStr HKCU "${REGKEY}" "InstallLocation" "$INSTDIR"
  WriteRegDWORD HKCU "${REGKEY}" "NoModify" 1
  WriteRegDWORD HKCU "${REGKEY}" "NoRepair" 1
SectionEnd

Section "Acceso directo en el escritorio" SecDesk
  CreateShortcut "$DESKTOP\${APPNAME}.lnk" "$INSTDIR\${EXENAME}" "" "$INSTDIR\icon.ico"
SectionEnd

Section /o "Iniciar con Windows" SecAuto
  WriteRegStr HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "DragonEscritorio" '"$INSTDIR\${EXENAME}"'
SectionEnd

!insertmacro MUI_FUNCTION_DESCRIPTION_BEGIN
  !insertmacro MUI_DESCRIPTION_TEXT ${SecMain} "El dragón y su programa."
  !insertmacro MUI_DESCRIPTION_TEXT ${SecDesk} "Crea un icono en el escritorio para despertar al dragón."
  !insertmacro MUI_DESCRIPTION_TEXT ${SecAuto} "El dragón aparecerá cada vez que enciendas el ordenador (se puede cambiar luego desde su menú)."
!insertmacro MUI_FUNCTION_DESCRIPTION_END

Section "Uninstall"
  nsExec::Exec 'taskkill /IM ${EXENAME} /F'
  Sleep 400
  Delete "$INSTDIR\${EXENAME}"
  Delete "$INSTDIR\WebView2Loader.dll"
  Delete "$INSTDIR\LEEME.txt"
  Delete "$INSTDIR\icon.ico"
  Delete "$INSTDIR\Desinstalar.exe"
  RMDir "$INSTDIR"
  Delete "$SMPROGRAMS\${APPNAME}\${APPNAME}.lnk"
  Delete "$SMPROGRAMS\${APPNAME}\Desinstalar.lnk"
  RMDir "$SMPROGRAMS\${APPNAME}"
  Delete "$DESKTOP\${APPNAME}.lnk"
  DeleteRegValue HKCU "Software\Microsoft\Windows\CurrentVersion\Run" "DragonEscritorio"
  DeleteRegKey HKCU "${REGKEY}"
SectionEnd
