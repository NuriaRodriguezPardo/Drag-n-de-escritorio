import sys, asyncio
from playwright.async_api import async_playwright
async def main(url, out, w, h):
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--no-sandbox'])
        pg = await b.new_page(viewport={'width': int(w), 'height': int(h)})
        pg.on('console', lambda m: print('CONSOLE', m.type, m.text) if m.type in ('error','warning') else None)
        pg.on('pageerror', lambda e: print('PAGEERROR', e))
        await pg.goto(url)
        try: await pg.wait_for_function("document.title==='READY'", timeout=60000)
        except Exception as e: print('timeout', e)
        await pg.screenshot(path=out)
        await b.close()
asyncio.run(main(*sys.argv[1:5]))
