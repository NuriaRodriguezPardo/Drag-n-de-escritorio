import sys, asyncio, json
from playwright.async_api import async_playwright
# uso: play.py URL '[["wait",2],["shot","a.png"],["cmd","fire"],["js","..."],["mouse",x,y]]'
async def main(url, steps):
    async with async_playwright() as p:
        b = await p.chromium.launch(executable_path='/usr/bin/google-chrome', args=['--use-angle=swiftshader','--enable-unsafe-swiftshader','--no-sandbox','--autoplay-policy=no-user-gesture-required'])
        pg = await b.new_page(viewport={'width': 1280, 'height': 720})
        pg.on('console', lambda m: print('CONSOLE', m.type, m.text[:300]) if m.type in ('error',) else None)
        pg.on('pageerror', lambda e: print('PAGEERROR', e))
        await pg.goto(url)
        for st in json.loads(steps):
            k = st[0]
            if k == 'wait': await pg.wait_for_timeout(int(st[1]*1000))
            elif k == 'shot': await pg.screenshot(path=st[1])
            elif k == 'cmd': await pg.evaluate(f"window.__game.command('{st[1]}')")
            elif k == 'js': print('JS', await pg.evaluate(st[1]))
            elif k == 'mouse': await pg.mouse.move(st[1], st[2], steps=8)
            elif k == 'click': await pg.mouse.click(st[1], st[2])
        await b.close()
asyncio.run(main(sys.argv[1], sys.argv[2]))
