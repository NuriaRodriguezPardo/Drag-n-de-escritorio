#!/usr/bin/env python3
"""Genera el rig del dragón a partir de la ficha de diseño.

Salida (en app/public/assets):
  body.png, wing.png  -> texturas (2x)
  rig.json            -> huesos, mallas, UV y pesos
  hitmask.json        -> máscara de baja resolución para detectar el cursor
"""
import json, sys, os
import numpy as np, cv2

SRC = sys.argv[1]
OUT = sys.argv[2]
os.makedirs(OUT, exist_ok=True)
W, H = 600, 475          # coordenadas del rig (px del recorte original)
UP = 2                   # factor de la textura

sheet = cv2.imread(SRC, cv2.IMREAD_UNCHANGED)[:, :, :3]
crop = sheet[0:H, 0:W].copy()

# ---------- 1. Recorte con GrabCut a resolución 2x ----------
big = cv2.resize(crop, (W * UP, H * UP), interpolation=cv2.INTER_LANCZOS4)
# realce suave para compensar el reescalado
blur = cv2.GaussianBlur(big, (0, 0), 1.2)
big = cv2.addWeighted(big, 1.35, blur, -0.35, 0)

mask = np.zeros(crop.shape[:2], np.uint8)
bgm = np.zeros((1, 65)); fgm = np.zeros((1, 65))
cv2.grabCut(crop, mask, (8, 8, 585, 462), bgm, fgm, 10, cv2.GC_INIT_WITH_RECT)
m = np.where((mask == 1) | (mask == 3), 255, 0).astype(np.uint8)
n, lab, st, _ = cv2.connectedComponentsWithStats(m)
k = 1 + np.argmax(st[1:, 4]); m = np.where(lab == k, 255, 0).astype(np.uint8)
# rellenar agujeros pequeños (p. ej. el ojo ámbar, parecido al fondo)
inv = (m == 0).astype(np.uint8)
n2, lab2, st2, _ = cv2.connectedComponentsWithStats(inv, connectivity=4)
for i in range(1, n2):
    x_, y_, w_, h_, a_ = st2[i]
    if a_ < 260 and x_ > 0 and y_ > 0 and x_ + w_ < W and y_ + h_ < H:
        m[lab2 == i] = 255
mb = cv2.resize(m, (W * UP, H * UP), interpolation=cv2.INTER_LINEAR)
mb = cv2.GaussianBlur(mb, (0, 0), 1.0)
mb = np.clip((mb.astype(np.float32) - 110) * 255 / 120, 0, 255)  # erosión suave
alpha = mb / 255.0
# eliminar el halo beige del borde: oscurecer píxeles semitransparentes
edge = (alpha > 0.02) & (alpha < 0.98)
dark = np.array([28, 38, 58], np.float32)  # BGR marrón muy oscuro (contorno)
bigf = big.astype(np.float32)
t = (1 - alpha[..., None]) * 0.85
bigf = np.where(edge[..., None], bigf * (1 - t) + dark * t, bigf)
big = np.clip(bigf, 0, 255).astype(np.uint8)

# ---------- 2. Separar ala ----------
def poly_mask(pts, scale=UP):
    mm = np.zeros((H * scale, W * scale), np.uint8)
    cv2.fillPoly(mm, [np.int32(np.array(pts) * scale)], 255)
    return mm

WING_POLY = [(0, 0), (432, 0), (432, 62), (414, 86), (416, 170), (436, 197), (424, 230), (392, 247), (352, 257),
             (314, 266), (284, 283), (252, 304), (0, 306)]
wing_area = poly_mask(WING_POLY) > 0
# banda de raíz: píxeles del cuerpo justo bajo el borde del ala (se ve sólo al aletear)
root_band = cv2.dilate(wing_area.astype(np.uint8) * 255,
                       cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (2 * 28 * UP // 2, 2 * 28 * UP // 2))) > 0
root_band &= ~wing_area
dist = cv2.distanceTransform((~wing_area).astype(np.uint8), cv2.DIST_L2, 5) / UP  # px orig
band_alpha = np.clip(1 - (dist - 6) / 20, 0, 1)
# sólo la zona de hombro (no el lomo trasero) recibe banda
sh = np.zeros_like(band_alpha); cv2.fillPoly(sh, [np.int32(np.array(
    [(300, 240), (460, 160), (470, 300), (300, 320)]) * UP)], 1)
wing_alpha = np.where(wing_area, alpha, alpha * band_alpha * sh)
body_alpha = np.where(wing_area, 0, alpha)

def save_rgba(path, a):
    rgba = np.dstack([big, np.clip(a * 255, 0, 255).astype(np.uint8)])
    cv2.imwrite(path, rgba, [cv2.IMWRITE_PNG_COMPRESSION, 9])

save_rgba(os.path.join(OUT, 'body.png'), body_alpha)
save_rgba(os.path.join(OUT, 'wing.png'), wing_alpha)
save_rgba(os.path.join(OUT, 'dragon_full.png'), alpha)

# ---------- 3. Huesos ----------
bones = []
def bone(name, parent, px, py, end=None):
    bones.append(dict(name=name, parent=parent, px=px, py=py, end=end))
    return len(bones) - 1

root = bone('root', -1, 410, 445)
hips = bone('hips', root, 335, 330, (420, 330))
chest = bone('chest', root, 455, 320, (545, 312))
TJ = [(300, 325), (250, 348), (195, 362), (140, 372), (85, 382), (42, 398), (30, 422),
      (70, 442), (140, 444), (210, 446), (282, 452)]
tail = []
p = hips
for i in range(len(TJ) - 1):
    p = bone(f'tail{i}', p, *TJ[i], end=TJ[i + 1]); tail.append(p)
NJ = [(505, 298), (505, 250), (500, 195), (488, 145), (482, 105)]
neck = []
p = chest
for i in range(len(NJ) - 1):
    p = bone(f'neck{i}', p, *NJ[i], end=NJ[i + 1]); neck.append(p)
head = bone('head', p, 482, 105, (578, 118))
LEGS = {
    'HN': (hips, [(335, 335), (315, 392), (300, 430), (285, 452)]),
    'HF': (hips, [(405, 340), (378, 395), (410, 432), (430, 450)]),
    'FF': (chest, [(465, 340), (468, 395), (490, 438), (505, 455)]),
    'FN': (chest, [(525, 335), (528, 395), (535, 438), (555, 458)]),
}
legb = {}
for k_, (par, J) in LEGS.items():
    p = par; ids = []
    for i, nm in enumerate(['up', 'low', 'foot']):
        p = bone(f'{k_}_{nm}', p, *J[i], end=J[i + 1]); ids.append(p)
    legb[k_] = ids
wroot = bone('wing', chest, 418, 214, (395, 35))
wtip = bone('wingTip', wroot, 392, 40, (60, 120))
wfroot = bone('wingFar', chest, 438, 206, (415, 30))
wftip = bone('wingFarTip', wfroot, 412, 34, (80, 110))

LEG_POLY = {
    'HN': [(292, 300), (382, 306), (376, 345), (348, 400), (342, 475), (262, 475), (282, 400), (288, 340)],
    'HF': [(382, 328), (442, 334), (452, 475), (384, 475), (350, 405), (376, 345)],
    'FF': [(440, 338), (503, 336), (509, 438), (513, 475), (462, 475), (444, 400)],
    'FN': [(503, 336), (580, 326), (585, 475), (513, 475), (509, 438)],
}
leg_masks = {k_: poly_mask(v, 1) > 0 for k_, v in LEG_POLY.items()}

def seg_dist(P, a, b):
    a = np.array(a, float); b = np.array(b, float)
    ab = b - a; t = np.clip(((P - a) @ ab) / (ab @ ab), 0, 1)
    return np.linalg.norm(P - (a + t[:, None] * ab), axis=1)

def bseg(i):
    b = bones[i]; return (b['px'], b['py']), b['end']

# ---------- 4. Mallas ----------
def build_mesh(a_full, step, label_fn=None, split_y=375):
    a = cv2.resize(a_full, (W, H), interpolation=cv2.INTER_AREA)
    occ = a > 0.01
    gw, gh = W // step + 2, H // step + 2
    vid = {}; verts = []; vlab = []
    def v(gx, gy, lab):
        key = (gx, gy, lab)
        if key not in vid:
            vid[key] = len(verts); verts.append((min(gx * step, W), min(gy * step, H))); vlab.append(lab)
        return vid[key]
    tris = []
    for gy in range(gh - 1):
        for gx in range(gw - 1):
            x0, y0 = gx * step, gy * step
            if not occ[y0:min(y0 + step + 1, H), x0:min(x0 + step + 1, W)].any():
                continue
            cx, cy = x0 + step / 2, y0 + step / 2
            lab = 'S'
            if label_fn is not None and cy > split_y:
                lab = label_fn((cx, cy))
            a_, b_, c_, d_ = v(gx, gy, lab), v(gx + 1, gy, lab), v(gx + 1, gy + 1, lab), v(gx, gy + 1, lab)
            tris.append((a_, b_, c_, gx, gy)); tris.append((a_, c_, d_, gx, gy))
    return np.array(verts, float), tris, vlab

def weights_for(P, cand_fn, smooth_adj=None, iters=4, vlab=None):
    nb = len(bones); Wm = np.zeros((len(P), nb))
    for vi, pt in enumerate(P):
        for bi in cand_fn(pt, vlab[vi] if vlab else 'S'):
            a, b = bseg(bi)
            d = seg_dist(pt[None], a, b)[0]
            Wm[vi, bi] = 1.0 / (d + 3.0) ** 4
    Wm /= Wm.sum(1, keepdims=True)
    if smooth_adj is not None:
        for _ in range(iters):
            Wn = np.zeros_like(Wm)
            for vi, ns in enumerate(smooth_adj):
                Wn[vi] = 0.5 * Wm[vi] + 0.5 * Wm[ns].mean(0)
            Wm = Wn
    # top-4
    idx = np.argsort(-Wm, 1)[:, :4]
    ww = np.take_along_axis(Wm, idx, 1); ww /= ww.sum(1, keepdims=True)
    return idx, ww

def adjacency(nv, tris):
    adj = [set() for _ in range(nv)]
    for a, b, c, *_ in tris:
        adj[a] |= {b, c}; adj[b] |= {a, c}; adj[c] |= {a, b}
    return [list(s) for s in adj]

AXIAL = [hips, chest] + tail + neck + [head]
def body_region(pt):
    x, y = int(min(max(pt[0], 0), W - 1)), int(min(max(pt[1], 0), H - 1))
    if y > 432 and x < 291:
        return 'AX'  # punta de la cola
    for k_, mm in leg_masks.items():
        if mm[y, x]:
            return k_
    return 'AX'

def body_cand(pt, lab='S'):
    r = body_region(pt) if lab == 'S' else lab
    if r == 'AX':
        return AXIAL
    par = LEGS[r][0]
    return legb[r] + [par]

def export_mesh(P, tris, idx, ww, order_key):
    tris = sorted(tris, key=order_key)
    return dict(
        pos=[round(float(c), 2) for p in P for c in p],
        idx=[int(i) for t in tris for i in t[:3]],
        bi=[int(i) for r in idx for i in r],
        bw=[round(float(w), 4) for r in ww for w in r],
    )

# cuerpo
P, tris, vlab = build_mesh(body_alpha, 6, body_region)
adj = adjacency(len(P), tris)
idx, ww = weights_for(P, body_cand, adj, 3, vlab)
ORDER = {'HF': 0, 'FF': 1, 'AX': 2, 'HN': 3, 'FN': 4}
def tri_order(t):
    cx = (P[t[0]][0] + P[t[1]][0] + P[t[2]][0]) / 3; cy = (P[t[0]][1] + P[t[1]][1] + P[t[2]][1]) / 3
    r = body_region((cx, cy))
    tl = 0
    if r == 'AX' and cx < 300 and cy > 300:
        tl = -0.5  # la cola por detrás del cuerpo
    return ORDER[r] + tl
body_mesh = export_mesh(P, tris, idx, ww, tri_order)

# ala (radial: raíz/punta)
Pw, trisw, _ = build_mesh(wing_alpha, 8)
sx, sy = 418, 214
def wing_weights(Pw, rb, tb):
    d = np.linalg.norm(Pw - np.array([sx, sy]), axis=1)
    t = np.clip((d - 90) / 230, 0, 1); t = t * t * (3 - 2 * t)
    idx = np.zeros((len(Pw), 4), int); ww = np.zeros((len(Pw), 4))
    idx[:, 0] = rb; idx[:, 1] = tb; idx[:, 2] = rb; idx[:, 3] = rb
    ww[:, 0] = 1 - t; ww[:, 1] = t
    return idx, ww
idx, ww = wing_weights(Pw, wroot, wtip)
wing_mesh = export_mesh(Pw, trisw, idx, ww, lambda t: 0)
idx2, ww2 = wing_weights(Pw, wfroot, wftip)
wing_far_mesh = dict(wing_mesh); wing_far_mesh['bi'] = [int(i) for r in idx2 for i in r]
wing_far_mesh['bw'] = [round(float(w), 4) for r in ww2 for w in r]

rig = dict(
    size=[W, H], texScale=UP,
    bones=[dict(name=b['name'], parent=b['parent'], px=b['px'], py=b['py'],
                end=list(b['end']) if b['end'] else None) for b in bones],
    meshes=dict(body=body_mesh, wing=wing_mesh, wingFar=wing_far_mesh),
    points=dict(eye=[543, 95], mouth=[578, 121], nostril=[572, 108], ground=[410, 458],
                pawFN=[555, 458], pawFF=[505, 455]),
    groundY=458,
)
with open(os.path.join(OUT, 'rig.json'), 'w') as f:
    json.dump(rig, f, separators=(',', ':'))

# máscara de impacto (1/4 de resolución) del dragón completo
hm = cv2.resize((alpha > 0.3).astype(np.uint8), (W // 4, H // 4), interpolation=cv2.INTER_AREA)
hm = cv2.dilate(hm, np.ones((3, 3), np.uint8))
with open(os.path.join(OUT, 'hitmask.json'), 'w') as f:
    json.dump(dict(w=W // 4, h=H // 4, s=4, d=''.join('1' if v else '0' for v in hm.flatten())), f)

print('huesos', len(bones), 'verts cuerpo', len(P), 'tris', len(body_mesh['idx']) // 3,
      'verts ala', len(Pw))
