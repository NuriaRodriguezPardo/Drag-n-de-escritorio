#!/bin/bash
# uso: shot.sh URL salida.png ancho alto
timeout 60 google-chrome --headless=new --no-sandbox --disable-gpu-sandbox --use-angle=swiftshader --enable-unsafe-swiftshader --hide-scrollbars --virtual-time-budget=8000 --window-size=$3,$4 --screenshot=$2 "$1" 2>/dev/null
